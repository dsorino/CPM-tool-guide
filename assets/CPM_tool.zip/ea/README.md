
# External Model for the Euro Area

This repository contains the external environment model for the Euro Area,
representing one of the key external economies in the forecasting system. It
provides projections for EA's GDP, inflation, interest rate, and exchange
rate that influence the domestic economies being modeled.

