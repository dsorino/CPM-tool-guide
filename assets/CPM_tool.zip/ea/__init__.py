
COUNTRY_CODE = "EA"
COUNTRY_NAME = "Euro Area"

