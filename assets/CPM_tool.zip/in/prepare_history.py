r"""
Prepare historical data for the Philippines model
"""


#[

# Standard library imports
from pprint import pprint
import functools as ft
import json

# Third-party imports
import datapie as dp

# Application imports
import datastore_api as api
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


GDP_SCALE = 1e13
CPI_SCALE = 1e2
E_SCALE = 1e2

HISTORY_END_VARIABLE = "gdp_nsa"


#%% Defining attributes
logger.info("Defining attributes")

attributes = mi.read_attributes_from_json_file(fs.ATTRIBUTES_FILE, )
pprint(attributes, )


#%% Reading data and parameters in from data file
logger.info("Reading data in from data file")

db = dp.Databox.from_csv_file(
    fs.REQUEST_DATA_FILE,
    description_row=True,
)

with open(fs.PARAMETERS_FILE, "rt", ) as f:
    parameters = json.load(f, )


#%% Defining time periods and spans
logger.info("Defining time periods and spans")

history_start = attributes["history_start_period"]
forecast_end = attributes["forecast_end_period"]
history_end = db[HISTORY_END_VARIABLE].end
history_span = history_start >> history_end
forecast_start = history_end + 1
forecast_span = forecast_start >> forecast_end
filter_span = history_start >> forecast_end


#%% Aggregating monthly data to quarterly data
logger.info("Aggregating monthly data to quarterly data")

monthly_names = db.filter(name_test=lambda n: n.startswith("mm_"))
aggregate = ft.partial(dp.aggregate, target_freq=dp.QUARTERLY, method="mean", )
for monthly_name in monthly_names:
    quarterly_name = monthly_name.replace("mm_", "", )
    db[quarterly_name] = aggregate(db[monthly_name], )


#%% Seasonally adjusting data
logger.info("Seasonally adjusting data")

nsa_names = db.filter(name_test=lambda n: n.endswith("_nsa"))
for nsa_name in nsa_names:
    sa_name = nsa_name.replace("_nsa", "", )
    tc_name = nsa_name.replace("_nsa", "_tc")
    db[sa_name] = dp.x13(db[nsa_name], )
    db[tc_name] = dp.x13(db[nsa_name], output="tc", )


#%% Define external variables
logger.info("Defining external variables")

db["gdpw"] = db["us_gdp"]
db["cpiw"] = db["us_cpi"]
db["iw"] = db["us_i"]
db["gdpw_tnd"] = db["us_gdp_tnd"]
db["roc_cpiw_tnd"] = db["us_roc_cpi_tnd"]
db["riw_tnd"] = db["us_ri_tnd"]

# Define external (excl US) GDP rate gap
db["gdpx_gap"] = (
    (db["cn_gdp"]/db["cn_gdp_tnd"]) ** parameters["tw_cn"]
    * (db["jp_gdp"]/db["jp_gdp_tnd"]) ** parameters["tw_jp"]
    * (db["ea_gdp"]/db["ea_gdp_tnd"]) ** parameters["tw_ea"]
) ** (1/(parameters["tw_cn"] + parameters["tw_jp"] + parameters["tw_ea"]))

# Define external (excl US) real exchange rate gap
db["rex_gap"] = (
    (db["cn_re"]/db["cn_re_tnd"]) ** parameters["tw_cn"]
    * (db["jp_re"]/db["jp_re_tnd"]) ** parameters["tw_jp"]
    * (db["ea_re"]/db["ea_re_tnd"]) ** parameters["tw_ea"]
) ** (1/(parameters["tw_cn"] + parameters["tw_jp"] + parameters["tw_ea"]))


#%% Calculating data transformations
logger.info("Calculating data transformations")

gdp_components = ("cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx", )


# Rescale levels for numerical reasons

for n in gdp_components + ("gdp", ):
    db[n] = db[n] / GDP_SCALE
    db[f"n{n}"] = db[f"n{n}"] / GDP_SCALE

db["cpi"] = db["cpi"] / CPI_SCALE
db["e"] = db["e"] / E_SCALE


# Define domestic absorption
db["dab"] = db["cpr"] + db["cgg"] + db["fcf"]

db["sdx"] = db("gdp - (cpr + cgg + fcf + xgs - mgs + cbi)", )

# Define ratios to real GDP
for n in ("dab", "cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx", ):
    db[f"{n}_to_gdp"] = db[f"{n}"] / db["gdp"]

for n in ("cpiw", "gdpw", "cpi", "gdp", "dab", "cpr", "cgg", "fcf", "xgs", "mgs", ): # "cbi", "sdx", ):
    db[f"roc_{n}"] = dp.roc(db[f"{n}"], )
    db[f"pct_{n}"] = dp.pct(db[f"{n}"], )
    db[f"apct_{n}"] = dp.apct(db[f"{n}"], )
    db[f"pct4_{n}"] = dp.pct(db[f"{n}"], -4, )


# Define ex-post real interest rates and real exchange rates

db["i"] = db["i"] / 100
db["ri_ex"] = db["i"] - 4*dp.log(db["roc_cpi"][+1])
db["re"] = db["cpiw"] * db["e"] / db["cpi"]
db["pxgs"] = db["nxgs"] / db["xgs"]
db["pmgs"] = db["nmgs"] / db["xgs"]
db["tot"] = db["pxgs"] / db["pmgs"]

for n in ("re", ):
    db[f"apct_{n}"] = dp.apct(db[f"{n}"], )
    db[f"pct4_{n}"] = dp.pct(db[f"{n}"], -4, )


# Define GDP identity and residuals
db['gdp_ident'] = db('cpr + cgg + fcf + xgs - mgs + cbi_to_gdp*gdp + sdx_to_gdp*gdp')
db['gdp_resid'] = db('gdp_ident / gdp')


#%% Calculating annual time series
logger.info("Calculating annual time series")

for n in (
    "gdp", "cpi", "e", "i", "tot", "re", "ri_ex",
    "cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx",
):
    if (n not in db) or (f"yy_{n}" in db):
        continue
    db[f"yy_{n}"] = dp.aggregate(db[n], dp.YEARLY, "mean", )


#%% Writing data to CSV file
logger.info("Writing data to CSV file")

# Keep only quarterly seasonally adjusted series
keep_names = db.filter(
    name_test=lambda n: not n.endswith("_nsa") and not n.startswith("mm_"),
)

# Create a shallow copy of the databox with only the desired series
db_to_write = db.shallow(
    source_names=keep_names,
    strict_names=True,
)

# Add dummy series for time spans
db_to_write["history_span"] = dp.Series(periods=history_span, values=1, )
db_to_write["forecast_span"] = dp.Series(periods=forecast_span, values=1, )
db_to_write["filter_span"] = dp.Series(periods=filter_span, values=1, )

# Write data to CSV file
db_to_write.to_csv_file(fs.PREPROCESSED_DATA_FILE, )


#%% Generating tune files
logger.info("Generating tune files")

yy_forecast_start = dp.refrequent(forecast_start, dp.YEARLY)
db_to_write.clip_series(None, yy_forecast_start-1, )
mi.generate_annual_tune_file(db_to_write, fs.ANNUAL_TUNE_FILE, )


logger.info("Done preparing data")

