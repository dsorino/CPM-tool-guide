r"""
Prepare historical observables and run Kalman filter to obtain the estimates of
unobserved components.
"""

#[

# Standard library imports
import os

# Third-party imports
import datapie as dp
import irispie as ir

# Application imports
from reporting_infrastructure import logger
import model_infrastructure as mi

# Local imports
from . import file_structure as fs

#]


#%% Loading model, data and spans
logger.info("Loading model, data and spans", )

model = ir.Simultaneous.from_pickle_file(fs.MODEL_PICKLE_FILE, )
model.check_steady()
model.solve_first_order()

db = ir.Databox.from_csv_file(fs.PREPROCESSED_DATA_FILE, )
filter_span = db["filter_span"].span


#%% Creating databox with observables
logger.info("Creating databox with observables", )

obs_names = (
    "gdpw", "cpiw", "iw", "gdpx_gap", "rex_gap", "gdpw_tnd", "roc_cpiw_tnd", "riw_tnd",
    "gdp", "cpr", "cgg", "fcf", "xgs", "mgs", "cbi_to_gdp", "sdx_to_gdp",
    "tot", "e", "i", "cpi",
)

max_values = {
    n: ir.nanmax(db[n], axis=0, )
    for n in obs_names
}
print("Max value among observables:", max(max_values.values()), )

obs_db = db.copy(
    source_names=obs_names,
    target_names=lambda n: "obs_" + n,
)



#%% Setting up covid dummies
logger.info("Setting up covid dummies")

#==============================================================
# COVID shock standard deviations
covid_span = ir.qq(2020,1) >> ir.qq(2020,4)

stds = model.get_stds()

std_db = ir.Databox()
std_db["std_shk_gdp_tnd"] = ir.Series(
    periods=covid_span,
    values=stds["std_shk_gdp_gap"] * 5,
)
std_db["std_shk_gdpw_tnd"] = ir.Series(
    periods=covid_span,
    values=stds["std_shk_gdpw_gap"] * 5,
)
std_db = model.vary_stds(
    multiplier_db=None,
    overwrite_db=std_db,
    span=filter_span,
)
#==============================================================


#%% Running Kalman filter
logger.info("Running Kalman filter")

filter_db, info, = model.kalman_filter(
    obs_db | std_db, filter_span,
    return_=("predict", "update", "smooth", ),
    return_info=True,
    rescale_variance=True,
    stds_from_data=True,
)


#%% Writing filter data to CSV files
logger.info("Writing filter data to CSV files")

filter_db_med = filter_db["smooth_med"]
filter_db_std = filter_db["smooth_std"]

diagn_db = dp.Databox()
diagn_db["nllc"] = info["neg_log_likelihood_contributions"].copy()
for n in filter_db_med.keys():
    diagn_db[f"predict_{n}"] = filter_db["predict_med"][n].copy()
    diagn_db[f"update_{n}"] = filter_db["update_med"][n].copy()
    diagn_db[f"smooth_{n}"] = filter_db["smooth_med"][n].copy()

filter_db_predict_med = filter_db["predict_med"]
filter_db_update_med = filter_db["update_med"]

filter_db_med["history_span"] = db["history_span"]
filter_db_med["forecast_span"] = db["forecast_span"]
filter_db_med["filter_span"] = db["filter_span"]

filter_db_med.to_csv_file(fs.FILTER_MED_DATA_FILE, )
diagn_db.to_csv_file(fs.DIAGN_DATA_FILE, )
filter_db_std.to_csv_file(fs.FILTER_STD_DATA_FILE, )


logger.info("Done filtering historical data", )

