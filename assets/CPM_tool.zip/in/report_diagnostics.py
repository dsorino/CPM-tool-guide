r"""
"""

#[

# Third-party imports
import datapie as dp

# Application imports
import reporting_infrastructure as ri
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs
from . import COUNTRY_NAME

#]


#%% Preparing data
logger.info("Preparing data", )

filter_db = dp.Databox.from_csv_file(fs.FILTER_MED_DATA_FILE, )
filter_span = filter_db["filter_span"].span
report_span = filter_span.start+4 >> filter_span.end
db = dp.Databox.from_csv_file(fs.DIAGN_DATA_FILE, )


#%% Plotting diagnostics for transition shock estimates
logger.info("Plotting diagnostics for transition shock estimates", )

ch = ri.chartpack_transition_shocks.copy()
ch.set_span(report_span, )
ch.modify_figure_titles(
    lambda t: t.format(country=COUNTRY_NAME),
)
ch.plot(db, )


#%% Plotting diagnostics for generalized perrs
logger.info("Plotting diagnostics for generalized perrs", )

ch = ri.chartpack_generalized_perrs.copy()
ch.set_span(report_span, )
ch.modify_figure_titles(
    lambda t: t.format(country=COUNTRY_NAME),
)
ch.plot(db, )


#%% Plotting diagnostics for trend estimates
logger.info("Plotting diagnostics for trend estimates", )

ch = ri.chartpack_trend_estimates.copy()
ch.set_span(report_span, )
ch.modify_figure_titles(
    lambda t: t.format(country=COUNTRY_NAME),
)
ch.plot(db, )

