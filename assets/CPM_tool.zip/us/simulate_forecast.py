r"""
Simulate forecast
"""

#[

# Standard library imports
import os
import sys

# Third-party imports
import irispie as ir

# Application imports
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


SOLVER_SETTINGS = {"step_tolerance": 1, }


#%% Reading in data and date spans
logger.info("Loading data and date spans", )

filter_db = ir.Databox.from_csv_file(fs.FILTER_MED_DATA_FILE, )

filter_span = filter_db["filter_span"].span
filter_start = filter_span.start
forecast_span = filter_db["forecast_span"].span
forecast_start = forecast_span.start
forecast_end = forecast_span.end


#%% Loading and solving model
logger.info("Loading and solving model", )

model = ir.Simultaneous.from_pickle_file(fs.MODEL_PICKLE_FILE, )
model.check_steady()
model.solve_first_order()


#%% Preparing input data for simulation
logger.info("Preparing input data for simulation", )

input_db = filter_db.copy()
shock_names = model.get_names(kind=ir.ANY_SHOCK, )
input_db.remove(shock_names, )


#%% Simulating model forecast
logger.info("Simulating model forecast", )

plan = ir.SimulationPlan(model, forecast_span, )

# Add annual tunes from the tune file
annual_tune_db = ir.Databox.from_csv_file(fs.ANNUAL_TUNE_FILE, )
mi.add_annual_tunes(
    plan,
    input_db,
    annual_tune_db,
)

#==============================================================
# Add judgmental adjustments here

#==============================================================

fcast_db = model.simulate(
    input_db, forecast_span,
    method="stacked_time",
    solver_settings=SOLVER_SETTINGS,
    plan=plan,
)

mi.postprocess_external_simulation(fcast_db, )

entire_span = filter_start >> forecast_end
fcast_db["rew"] = ir.Series(periods=entire_span, values=1, )
fcast_db["rew_tnd"] = ir.Series(periods=entire_span, values=1, )
fcast_db["rew_gap"] = ir.Series(periods=entire_span, values=1, )


#%% Writing forecast out to data file
logger.info("Writing forecast out to data file", )

fcast_db["filter_span"] = filter_db["filter_span"]
fcast_db["forecast_span"] = filter_db["forecast_span"]
fcast_db.to_csv_file(fs.FORECAST_DATA_FILE, )


logger.info("Done simulating forecast", )

