# United States External Model

This repository contains the external environment model for the United States,
representing a key external economy in the forecasting system. It provides
projections for US GDP, inflation, and interest rates that serve as external
conditions for the domestic country models.

