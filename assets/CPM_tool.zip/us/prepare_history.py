r"""
"""

#[

# Standard library imports
import os
import sys
import functools as ft
from pprint import pprint

# Third-party imports
import datapie as ap

# Application imports
import datastore_api as api
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


GDPW_SCALE = 1e4
CPIW_SCALE = 1e2

HISTORY_END_VARIABLE = "gdpw"


#%% Defining attributes
logger.info("Defining attributes")

attributes = mi.read_attributes_from_json_file(fs.ATTRIBUTES_FILE, )
pprint(attributes, )


#%% Reading data in from data file
logger.info("Reading data in from data file")

db = ap.Databox.from_csv_file(
    fs.REQUEST_DATA_FILE,
    description_row=True,
)


#%% Defining time periods and spans
logger.info("Defining time periods and spans")

history_start = attributes["history_start_period"]
forecast_end = attributes["forecast_end_period"]
history_end = db[HISTORY_END_VARIABLE].end
history_span = history_start >> history_end
forecast_start = history_end + 1
forecast_span = forecast_start >> forecast_end
filter_span = history_start >> forecast_end


#%% Rescaling data
logger.info("Rescaling data")

db["gdpw"] = db["gdpw"] / GDPW_SCALE
db["mm_cpiw"] = db["mm_cpiw"] / CPIW_SCALE
db["mm_iw"] = db["mm_iw"] / 100


#%% Aggregating monthly data to quarterly data
logger.info("Aggregating monthly data to quarterly data")

monthly_mean_names = (
    "mm_cpiw",
    "mm_iw",
)

aggregate = ft.partial(
    ap.aggregate,
    target_freq=ap.QUARTERLY,
    method="mean",
)

for monthly_name in monthly_mean_names:
    quarterly_name = monthly_name.replace("mm_", "", )
    db[quarterly_name] = aggregate(db[monthly_name], )


#%% Seasonally adjusting data
logger.info("Seasonally adjusting data")

nsa_names = ()
for nsa_name in nsa_names:
    sa_name = nsa_name.replace("_nsa", "", )
    tc_name = nsa_name.replace("_nsa", "_tc")
    db[sa_name] = ap.x13(db[nsa_name], )
    db[tc_name] = ap.x13(db[nsa_name], output="tc", )


#%% Calculating data transformations
logger.info("Calculating data transformations")


for n in ("cpiw", "gdpw", ):
    db[f"roc_{n}"] = ap.roc(db[f"{n}"], )
    db[f"pct_{n}"] = ap.pct(db[f"{n}"], )
    db[f"apct_{n}"] = ap.apct(db[f"{n}"], )
    db[f"pct4_{n}"] = ap.pct(db[f"{n}"], -4, )


# Define ex-post real interest rates and real exchange rates

db["riw"] = db["iw"] - 4*ap.log(db["roc_cpiw"][+1])


# Create dummy series for the USD exchange rate

db["ew"] = ap.Series(periods=history_span, values=1, )


#%% Calculating annual time series
logger.info("Calculating annual time series")

for n in ("gdpw", "cpiw", "iw"):
    if (n not in db) or (f"yy_{n}" in db):
        continue
    db[f"yy_{n}"] = ap.aggregate(db[n], ap.YEARLY, "mean", )


#%% Writing data to CSV file
logger.info("Writing data to CSV file")

# Keep only quarterly seasonally adjusted series
keep_names = db.filter(
    name_test=lambda n: not n.endswith("_nsa") and not n.startswith("mm_"),
)

# Create a shallow copy of the databox with only the desired series
db_to_write = db.shallow(
    source_names=keep_names,
    strict_names=True,
)

# Add dummy series for time spans
db_to_write["history_span"] = ap.Series(periods=history_span, values=1, )
db_to_write["forecast_span"] = ap.Series(periods=forecast_span, values=1, )
db_to_write["filter_span"] = ap.Series(periods=filter_span, values=1, )

# Write data to CSV file
db_to_write.to_csv_file(fs.PREPROCESSED_DATA_FILE, )


#%% Generating tune files
logger.info("Generating tune files")

yy_forecast_start = ap.refrequent(forecast_start, ap.YEARLY)
db_to_write.clip_series(None, yy_forecast_start-1, )
mi.generate_external_annual_tune_file(db_to_write, fs.ANNUAL_TUNE_FILE, )


logger.info("Done preparing data")

