
import os
import functools as ft
import irispie as ir


__all__ = (
    "postprocess_simulation",
    "postprocess_external_simulation",
)


aggregate_sum = ft.partial(
    ir.aggregate,
    target_freq=ir.Frequency.YEARLY,
    method="sum",
)

aggregate_mean = ft.partial(
    ir.aggregate,
    target_freq=ir.Frequency.YEARLY,
    method="mean",
)


def postprocess_simulation(db: ir.Databox, ) -> None:
    r"""
    """

    # External economy

    # for n in ("cpiw", "gdpw", "gdpw_tnd", ):
    #     db[f"apct_{n}"] = ir.apct(db[f"{n}"])
    #     db[f"pct4_{n}"] = ir.pct(db[f"{n}"], -4, )

    # for n in ("iw", "riw", "cpiw", ):
    #     db[f"yy_{n}"] = aggregate_mean(db[f"{n}"])

    # for n in ("gdpw", "gdpw_tnd", ):
    #     db[f"yy_{n}"] = aggregate_sum(db[f"{n}"])

    # for n in ("cpiw", "gdpw", "gdpw_tnd", ):
    #     db[f"yy_pct_{n}"] = ir.pct(db[f"yy_{n}"])

    # for n in ("gdpw", ):
    #     db[f"yy_{n}_gap"] = db[f"yy_{n}"] / db[f"yy_{n}_tnd"]

    # Domestic economy

    for n in ("cbi", "sdx"):
        db[f"{n}"] = db[f"{n}_to_gdp"] * db["gdp"]

    for n in ("cpi", "re", "gdp", "cpr", "cgg", "fcf", "xgs", "mgs"):
        db[f"apct_{n}"] = ir.apct(db[f"{n}"])

    for n in ("cpi", "i", "e", "tot", "ri", "re", "ri_tnd", "re_tnd", ):
        db[f"yy_{n}"] = aggregate_mean(db[f"{n}"])

    for n in ("gdp", "cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx"):
        db[f"yy_{n}"] = aggregate_sum(db[f"{n}"])

    for n in ("gdp", "cpr", "cgg", "fcf", "xgs", "mgs"):
        db[f"yy_{n}_tnd"] = aggregate_sum(db[f"{n}_tnd"])
        db[f"yy_{n}_gap"] = db[f"yy_{n}"] / db[f"yy_{n}_tnd"]
        db[f"yy_pct_{n}"] = ir.pct(db[f"yy_{n}"])

    for n in ("cpi", "re", "re_tnd", ):
        db[f"yy_pct_{n}"] = ir.pct(db[f"yy_{n}"])

    for n in ("cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx"):
        db[f"yy_{n}_to_gdp"] = db[f"yy_{n}"] / db["yy_gdp"]


def postprocess_external_simulation(db: ir.Databox, ) -> None:
    r"""
    """

    for n in ("cpiw", "gdpw", "gdpw_tnd", "ew", ):
        db[f"apct_{n}"] = ir.apct(db[f"{n}"])
        db[f"pct4_{n}"] = ir.pct(db[f"{n}"], -4, )

    for n in ("iw", "riw", "cpiw", "ew", ):
        db[f"yy_{n}"] = aggregate_mean(db[f"{n}"])

    for n in ("gdpw", "gdpw_tnd", ):
        db[f"yy_{n}"] = aggregate_sum(db[f"{n}"])

    for n in ("cpiw", "ew", "gdpw", "gdpw_tnd", ):
        db[f"yy_pct_{n}"] = ir.pct(db[f"yy_{n}"])

    for n in ("gdpw", ):
        db[f"yy_{n}_gap"] = db[f"yy_{n}"] / db[f"yy_{n}_tnd"]

