
#[

from __future__ import annotations

# Typing imports
from typing import Any

# Standard library imports
import json

# Third-party imports
import datapie as dp

#]


__all__ = (
    "read_attributes_from_json_file",
)


def read_attributes_from_json_file(
    json_file: str,
) -> dict[str, Any]:
    r"""
    """
    with open(json_file, "rt", encoding="utf-8", ) as f:
        attributes = json.load(f, )

    for k, v in attributes.items():
        if k.endswith("_period"):
            attributes[k] = dp.Period.from_sdmx_string(v, )

    return attributes


