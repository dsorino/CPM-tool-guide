
#[

# Standard library imports
import sys
import os

# Third-party imports
import irispie as ir

#]


__all__ = (
    "model",
    "external_model",
    "create_model",
    "create_external_model",
)


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(THIS_DIR, "model_files", )

MODEL_FILES = [
    os.path.join(MODEL_DIR, "trends_and_identities.model", ),
    os.path.join(MODEL_DIR, "behavioral_gaps.model", ),
    os.path.join(MODEL_DIR, "annual_tunes.model", ),
    os.path.join(MODEL_DIR, "measurement.model", ),
    os.path.join(MODEL_DIR, "external.model", ),
    os.path.join(MODEL_DIR, "external_annual_tunes.model", ),
]

EXTERNAL_MODEL_FILES = [
    os.path.join(MODEL_DIR, "external.model", ),
    os.path.join(MODEL_DIR, "external_exchange_rate.model", ),
    os.path.join(MODEL_DIR, "external_annual_tunes.model", ),
]

ANNUAL_VARIABLES = (
    "roc4_ann_gdp",
    "roc4_ann_cpr",
    "roc4_ann_cgg",
    "roc4_ann_fcf",
    "roc4_ann_xgs",
    "roc4_ann_mgs",
    "roc4_ann_cpi",
    "ann_i",
)

EXTERNAL_ANNUAL_VARIABLES = (
    "roc4_ann_gdpw",
    "roc4_ann_cpiw",
    "ann_iw",
)

ANNUAL_DISTRIBUTION = (0.4, 0.6, 0.8, 1.0, )


# Make model objects with unassigned parameters available at the module level
model = ir.Simultaneous.from_file(MODEL_FILES, )
external_model = ir.Simultaneous.from_file(EXTERNAL_MODEL_FILES, )


def create_model(
    parameters: dict[str, float],
    #
    preparsed_model_file: str = "",
) -> ir.Simultaneous:
    r"""
    """

    model = ir.Simultaneous.from_file(
        MODEL_FILES,
        save_preparsed=preparsed_model_file,
        default_std=0,
    )
    model.override_tolerance(eigenvalue=1e-10, )

    default_parameters = {}

    default_parameters["ss_cbi_to_gdp"] = 0
    default_parameters["c1_roc_re_tnd"] = 0
    default_parameters["c1_disp_gap"] = 0.2

    for n in ANNUAL_VARIABLES + EXTERNAL_ANNUAL_VARIABLES:
        default_parameters[f"std_shk_{n}"] = 0
        default_parameters[f"c0_impact_{n}"] = ANNUAL_DISTRIBUTION[0]
        default_parameters[f"c1_impact_{n}"] = ANNUAL_DISTRIBUTION[1]
        default_parameters[f"c2_impact_{n}"] = ANNUAL_DISTRIBUTION[2]
        default_parameters[f"c3_impact_{n}"] = ANNUAL_DISTRIBUTION[3]

    for n in ("td", "bu", "2w"):
        default_parameters[f"std_shk_gdp_ident_{n}"] = 0

    for n in ("gdp_tnd", "gdpw_tnd", ):
        default_parameters[f"std_shk_{n}"] = 0

    for n in (
        "gdpw", "gdpw_tnd", "gdpx_gap", "rex_gap", "rewx_gap", "roc_cpiw",
        "roc_cpiw_tnd", "iw", "riw_tnd",
    ):
        default_parameters[f"std_tune_{n}"] = 0

    for n in ("roc_cpi", "i", "e", ):
        default_parameters[f"std_tune_{n}"] = 0

    model.assign_strict(default_parameters, )
    model.assign_strict(parameters, )

    plan = ir.SteadyPlan(model, )

    fix_levels = {
        "gdp": 1,
        "gdp_gap": 1,
        "tot": 1,
        "re": 1,
        "cpi": 1,

        "gdpw": 1,
        "gdpw_gap": 1,
        "cpiw": 1,
        "gdpx_gap": 1,
    }

    plan.fix_levels(list(fix_levels.keys()), )
    model.assign_strict(**fix_levels, )

    # Check that all parameters are assigned
    parameters = model.get_parameters()
    unassigned_parameters = set(
        n for n, v in parameters.items() if v is None
    )
    unassigned_parameters.remove("ss_mgs_to_gdp")
    if unassigned_parameters:
        raise ValueError(
            "The following parameters are unassigned: "
            f"{unassigned_parameters}"
        )

    # Check that all stds are assigned
    stds = model.get_stds()
    unassigned_stds = tuple(
        n for n, v in stds.items() if v is None
    )
    if unassigned_stds:
        raise ValueError(
            "The following standard deviations are unassigned: "
            f"{unassigned_stds}"
        )

    # plan.swap(["gdp_resid", "ss_mgs_to_gdp"])

    model.steady(plan=plan, )

    model.check_steady()

    model.solve_first_order()

    return model


def create_external_model(
    parameters: dict[str, float],
    preparsed_model_file: str = "",
) -> ir.Simultaneous:
    r"""
    """

    model = ir.Simultaneous.from_file(
        EXTERNAL_MODEL_FILES,
        save_preparsed=preparsed_model_file,
    )

    model.override_tolerance(eigenvalue=1e-10, )

    default_parameters = {}

    for n in EXTERNAL_ANNUAL_VARIABLES:
        default_parameters[f"std_shk_{n}"] = 0
        default_parameters[f"c0_impact_{n}"] = ANNUAL_DISTRIBUTION[0]
        default_parameters[f"c1_impact_{n}"] = ANNUAL_DISTRIBUTION[1]
        default_parameters[f"c2_impact_{n}"] = ANNUAL_DISTRIBUTION[2]
        default_parameters[f"c3_impact_{n}"] = ANNUAL_DISTRIBUTION[3]

    for n in ("gdpw", "gdpw_tnd", "roc_cpiw", "roc_cpiw_tnd", "iw", "riw_tnd", ):
        default_parameters[f"std_tune_{n}"] = 0

    for n in ("gdpw_tnd", ):
        default_parameters[f"std_shk_{n}"] = 0

    model.assign_strict(default_parameters, )
    model.assign_strict(parameters, )

    fix_levels = {
        "gdpw": 1,
        "gdpw_gap": 1,
        "cpiw": 1,
        "ew": 1,
    }

    steady_plan = ir.SteadyPlan(model, )
    steady_plan.fix_levels(list(fix_levels.keys()), )

    model.assign_strict(**fix_levels, )

    model.steady(plan=steady_plan, )
    model.check_steady()

    model.solve_first_order()

    return model

