# Model Infrastructure

This repository provides the core infrastructure and utilities for creating
and operating macroeconomic models across all countries. It contains shared
model templates, calibration tools, and common functions used by all
country-specific repositories.

