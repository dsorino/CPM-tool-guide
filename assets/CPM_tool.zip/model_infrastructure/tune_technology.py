r"""
"""

#[

# Standard library imports
import math

# Third-party imports
import irispie as ir


#]


__all__ = (
    "create_annual_tune",
    "add_annual_tunes",
    "generate_annual_tune_file",
    "generate_external_annual_tune_file",
)


SHOCK_NAME_TEMPLATE = "shk_{name}"
CX_IMPACT_NAME_TEMPLATE = "c{index}_impact_{name}"


def create_annual_tune(
    plan: ir.SimulationPlan,
    db: ir.Databox,
    variable_name: str,
    year: int,
    value: float,
) -> None:
    r"""
    """
    plan_start = plan.start
    shock_name = SHOCK_NAME_TEMPLATE.format(name=variable_name, )
    cx_names = tuple(
        CX_IMPACT_NAME_TEMPLATE.format(name=variable_name, index=i)
        for i in range(4)
    )
    #
    shock_quarter = 1
    if year == plan_start.year:
        shock_quarter = plan_start.period
    shock_period = ir.qq(year, shock_quarter)
    #
    year_end = ir.qq(year, 4)
    #
    plan.exogenize_anticipated(year_end, (variable_name,), )
    plan.endogenize_anticipated(shock_period, (shock_name,), )
    #
    if variable_name not in db:
        db[variable_name] = ir.Series()
    db[variable_name][year_end] = value
    #
    if shock_quarter > 1:
        if cx_names[3] not in db:
            db[cx_names[3]] = ir.Series()
        db[cx_names[3]][shock_period+3] = 0
    if shock_quarter > 2:
        if cx_names[2] not in db:
            db[cx_names[2]] = ir.Series()
        db[cx_names[2]][shock_period+2] = 0
    if shock_quarter > 3:
        if cx_names[1] not in db:
            db[cx_names[1]] = ir.Series()
        db[cx_names[1]][shock_period+1] = 0


def add_annual_tunes(
    plan: ir.SimulationPlan,
    input_db: ir.Databox,
    annual_tune_db: ir.Databox,
) -> None:
    r"""
    """
    annual_tune_start = ir.yy(plan.start.year)
    annual_tune_end = ir.yy(plan.end.year)
    annual_tune_span = annual_tune_start >> annual_tune_end
    #
    for n in annual_tune_db.get_names():
        if "_span" in n:
            continue
        if annual_tune_db[n].is_empty:
            continue
        values = annual_tune_db[n].get_values(annual_tune_span, )
        for t, v in zip(annual_tune_span, values, ):
            if v is None or math.isnan(v):
                continue
            create_annual_tune(plan, input_db, n, t.year, v, )


_NUM_HISTORICALR_YEARS = 4

_EXTERNAL_ANNUAL_TUNES = {
    "roc4_ann_gdpw": lambda db: ir.roc(db["yy_gdpw"]),
    "roc4_ann_cpiw": lambda db: ir.roc(db["yy_cpiw"]),
    "ann_iw": lambda db: db["yy_iw"],
}


_ANNUAL_TUNES = {
    "roc4_ann_gdp": lambda db: ir.roc(db["yy_gdp"]),
    "roc4_ann_cpr": lambda db: ir.roc(db["yy_cpr"]),
    "roc4_ann_cgg": lambda db: ir.roc(db["yy_cgg"]),
    "roc4_ann_fcf": lambda db: ir.roc(db["yy_fcf"]),
    "roc4_ann_xgs": lambda db: ir.roc(db["yy_xgs"]),
    "roc4_ann_mgs": lambda db: ir.roc(db["yy_mgs"]),
    "roc4_ann_cpi": lambda db: ir.roc(db["yy_cpi"]),
    "ann_i": lambda db: db["yy_i"],
    "ann_e": lambda db: db["yy_e"],
}


def generate_external_annual_tune_file(
    history_db: ir.Databox,
    target_file_path: str,
) -> None:
    r"""
    """

    history_span = history_db["history_span"].span
    forecast_span = history_db["forecast_span"].span

    yy_forecast_start = ir.refrequent(forecast_span.start, ir.YEARLY)
    yy_forecast_end = ir.refrequent(forecast_span.end, ir.YEARLY)
    yy_forecast_span = yy_forecast_start >> yy_forecast_end

    yy_tune_file_start = yy_forecast_start - _NUM_HISTORICALR_YEARS
    yy_tune_file_end = yy_forecast_end

    db_to_write = ir.Databox()

    db_to_write["forecast_span"] = ir.Series(
        periods=yy_forecast_span,
        values=1,
    )

    for name, func in _EXTERNAL_ANNUAL_TUNES.items():
        db_to_write[name] = func(history_db, )

    db_to_write.clip(yy_tune_file_start, yy_tune_file_end, )
    db_to_write.to_csv_file(target_file_path, )


def generate_annual_tune_file(
    history_db: ir.Databox,
    target_file_path: str,
) -> None:
    r"""
    """

    # Historical data

    history_span = history_db["history_span"].span
    forecast_span = history_db["forecast_span"].span

    yy_forecast_start = ir.refrequent(forecast_span.start, ir.YEARLY)
    yy_forecast_end = ir.refrequent(forecast_span.end, ir.YEARLY)
    yy_forecast_span = yy_forecast_start >> yy_forecast_end


    yy_tune_file_start = yy_forecast_start - _NUM_HISTORICALR_YEARS
    yy_tune_file_end = yy_forecast_end
    yy_tune_file_span = yy_tune_file_start >> yy_tune_file_end

    # Create tune files with historical data

    db_to_write = ir.Databox()

    db_to_write["forecast_span"] = ir.Series(
        periods=yy_forecast_span,
        values=1,
    )

    for name, func in _ANNUAL_TUNES.items():
        db_to_write[name] = func(history_db, )

    db_to_write.clip(yy_tune_file_start, yy_tune_file_end, )
    db_to_write.to_csv_file(target_file_path, )

