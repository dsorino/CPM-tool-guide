r"""
"""

#[

# Standard library imports
import os
from pprint import pp as pprint

# Third-party imports
import datapie as dp
import irispie as ir

# Application imports
from reporting_infrastructure import logger
import model_infrastructure as mi
from reporting_infrastructure import chartpack_steady_calibration as ch
from reporting_infrastructure import prepare_steady_calibration_data

# Local imports
from . import file_structure as fs
from . import COUNTRY_NAME

#]


#%% Loading model, data and spans
logger.info("Loading model, data and spans", )

model = ir.Simultaneous.from_pickle_file(fs.MODEL_PICKLE_FILE, )
db = ir.Databox.from_csv_file(fs.PREPROCESSED_DATA_FILE, )

prepare_steady_calibration_data(db, model, )

history_span = db["history_span"].span
yy_history_span = history_span.refrequent(dp.YEARLY, )
db.clip_series(yy_history_span.start, yy_history_span.end, )

ch.set_span(yy_history_span, )
ch.modify_figure_titles(lambda t: t.format(country=COUNTRY_NAME), )
ch.plot(db, )

