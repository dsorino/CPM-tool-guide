
#[

# Standard library imports
from pprint import pp as pprint

# Third-party imports
import datapie as dp

# Application imports
from reporting_infrastructure import logger
import model_infrastructure as mi
import datastore_api as api

# Local imports
from . import file_structure as fs

#]


#%% Reading attributes
logger.info("Reading attributes", )

attributes = mi.read_attributes_from_json_file(fs.ATTRIBUTES_FILE, )
pprint(attributes, )


#%% Reading forecast data
logger.info("Reading forecast data", )

forecast_db = dp.Databox.from_csv_file(fs.FORECAST_DATA_FILE, )


#%% Reading output mapping
logger.info("Reading output mapping", )

output_mapping = api.read_mapping_from_csv_file(
    fs.OUTPUT_MAPPING_FILE,
    attributes=attributes,
)


#%% Submitting forecast data
logger.info("Submitting forecast data", )

submission_db = api.submit(forecast_db, output_mapping, )


#%% Writing submission data
logger.info("Writing submission data", )

submission_db.to_csv_file(
    fs.SUBMISSION_DATA_FILE,
    description_row=True,
)


logger.info("Done submitting forecast data", )

