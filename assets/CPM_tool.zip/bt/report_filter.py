
#[

# Standard library imports
import os

# Third-party imports
import datapie as dp

# Application imports
from reporting_infrastructure import chartpack_filter as ch

# Local imports
from reporting_infrastructure  import logger
from . import file_structure as fs
from . import COUNTRY_NAME

#]


#%% Reading filter data
logger.info("Reading filter data", )

filter_db = dp.Databox.from_csv_file(fs.FILTER_MED_DATA_FILE, )
filter_span = filter_db["filter_span"].span
forecast_span = filter_db["forecast_span"].span


#%% Plotting filter results
logger.info("Plotting filter results", )

ch.set_span(filter_span, )
ch.set_highlight(forecast_span, )
ch.modify_figure_titles(lambda n: n.format(
    country=COUNTRY_NAME,
    external_country="External",
))

ch.plot(filter_db, )

