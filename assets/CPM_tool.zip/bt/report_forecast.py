

#[

# Standard library imports
import os

# Third-party imports
import datapie as dp

# Application imports
import model_infrastructure as mi
from reporting_infrastructure import logger
from reporting_infrastructure import chartpack_forecast as ch
from reporting_infrastructure import yy_chartpack_forecast as yy_ch

# Local imports
from . import file_structure as fs
from . import COUNTRY_NAME

#]


#%% Reading forecast data and spans
logger.info("Loading forecast data", )

db = dp.Databox.from_csv_file(fs.FORECAST_DATA_FILE, )

filter_span = db["filter_span"].span
forecast_span = db["forecast_span"].span
yy_filter_span = filter_span.refrequent(dp.YEARLY, )
yy_forecast_span = forecast_span.refrequent(dp.YEARLY, )


#%% Plotting forecast
logger.info("Plotting forecast", )

ch.set_span(filter_span, )
ch.set_highlight(forecast_span, )
ch.modify_figure_titles(lambda n: n.format(
    country=COUNTRY_NAME,
    external_country="External",
))

ch.plot(db, )


#%% Plotting forecast annualized
logger.info("Plotting forecast annualized", )

yy_ch.set_span(yy_filter_span, )
yy_ch.set_highlight(yy_forecast_span, )
yy_ch.modify_figure_titles(lambda n: n.format(
    country=COUNTRY_NAME,
    external_country="External",
))
yy_ch.plot(db, )

