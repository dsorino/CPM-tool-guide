
#[

# Standard library imports
import os

#]

THIS_DIR = os.path.dirname(os.path.abspath(__file__))

# Subdirectories
PICKLE_FILES_DIR = os.path.join(THIS_DIR, "pickle_files", )
MODEL_FILES_DIR = os.path.join(THIS_DIR, "model_files", )
DATA_FILES_DIR = os.path.join(THIS_DIR, "data_files")
TUNE_FILES_DIR = os.path.join(THIS_DIR, "tune_files")

# Configuration files
INPUT_MAPPING_FILE = os.path.join(THIS_DIR, "input_mapping.csv")
OUTPUT_MAPPING_FILE = os.path.join(THIS_DIR, "output_mapping.csv")
ATTRIBUTES_FILE = os.path.join(THIS_DIR, "attributes.json", )

# Pickle files
MODEL_PICKLE_FILE = os.path.join(PICKLE_FILES_DIR, "model.pkl", )

# Model related files
PREPARSED_MODEL_FILE = os.path.join(MODEL_FILES_DIR, "preparsed.model", )
PARAMETERS_FILE = os.path.join(MODEL_FILES_DIR, "parameters.json", )
STEADY_TABLE_FILE = os.path.join(MODEL_FILES_DIR, "steady_table.csv", )

# Data files
REQUEST_DATA_FILE = os.path.join(DATA_FILES_DIR, "request_data.csv", )
PREPROCESSED_DATA_FILE = os.path.join(DATA_FILES_DIR, "preprocessed_data.csv")
ANNUAL_TUNE_FILE = os.path.join(TUNE_FILES_DIR, "annual_tunes.csv")
FILTER_MED_DATA_FILE = os.path.join(DATA_FILES_DIR, "filter_med_data.csv")
DIAGN_DATA_FILE = os.path.join(DATA_FILES_DIR, "diagn_data.csv")
FILTER_STD_DATA_FILE = os.path.join(DATA_FILES_DIR, "filter_std_data.csv")
FORECAST_DATA_FILE = os.path.join(DATA_FILES_DIR, "forecast_data.csv")
SUBMISSION_DATA_FILE = os.path.join(DATA_FILES_DIR, "submission_data.csv")

