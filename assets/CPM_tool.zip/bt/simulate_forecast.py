r"""
Simulate forecast
"""

#[

# Third-party imports
import irispie as ir
import datapie as dp

# Application imports
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


SOLVER_SETTINGS = {"step_tolerance": 1, }


#%% Reading in data and date spans
logger.info("Reading in data and date spans", )

filter_db = ir.Databox.from_csv_file(fs.FILTER_MED_DATA_FILE, )

forecast_span = filter_db["forecast_span"].span
forecast_start = forecast_span.start
forecast_end = forecast_span.end


#%% Loading and solving model
logger.info("Loading and solving model", )

model = ir.Simultaneous.from_pickle_file(fs.MODEL_PICKLE_FILE, )
model.check_steady()
model.solve_first_order()


#%% Preparing input data for simulation
logger.info("Preparing input data for simulation", )

history_db = dp.Databox.from_csv_file(fs.PREPROCESSED_DATA_FILE, )
input_db = filter_db.copy()
input_db.clip(None, forecast_start-1, )

# Create dummy series for top-down GDP reconciliation
input_db["gdp_resid"] = ir.Series(periods=forecast_span, values=1, )


#%% Simulate model to produce forecast
logger.info("Simulating model to produce forecast", )

plan = ir.SimulationPlan(model, forecast_span, )

# Impose top-down GDP reconciliation
plan.swap_anticipated(..., ("gdp_resid", "shk_gdp_ident_td"))

# Add external data points
for n in ("roc_cpiw", "roc_cpiw_tnd", "iw", "riw_tnd", "gdpw", "gdpw_tnd", "gdpx_gap", "rex_gap", ):
    plan.swap_anticipated(forecast_span, (n, f"tune_{n}"), )
    x = filter_db[n](forecast_span)
    if x.has_missing:
        raise ValueError(f"Missing data for {n} in forecast span")
    input_db[n][forecast_span] = filter_db[n][forecast_span]

# Add data points avaliable after the forecast start
history_db["e"] = history_db["in_e"]
for n in ("roc_cpi", "i", "e", ):
    if history_db[n].end < forecast_start:
        continue
    span = forecast_start >> history_db[n].end
    plan.swap_anticipated(span, (n, f"tune_{n}"), )
    input_db[n][span] = history_db[n][span]

# Add annual tunes from the tune file
annual_tune_db = ir.Databox.from_csv_file(fs.ANNUAL_TUNE_FILE, )
mi.add_annual_tunes(
    plan,
    input_db,
    annual_tune_db,
)


#==============================================================
# Add judgmental adjustments here

#==============================================================


fcast_db = model.simulate(
    input_db, forecast_span,
    method="stacked_time",
    solver_settings=SOLVER_SETTINGS,
    plan=plan,
)

mi.postprocess_simulation(fcast_db, )


#%% Write forecast out to data file
logger.info("Writing forecast out to data file", )

fcast_db["filter_span"] = filter_db["filter_span"]
fcast_db["forecast_span"] = filter_db["forecast_span"]
fcast_db.to_csv_file(fs.FORECAST_DATA_FILE, )


logger.info("Done simulating forecast", )

