# Bhutan Economic Model

This repository contains the macroeconomic forecasting model and workflow for
Bhutan. It includes tools for creating economic models, preparing historical
data, filtering trends, and generating forecasts for key macroeconomic
variables like GDP, inflation, and exchange rates.
