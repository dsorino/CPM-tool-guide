
COUNTRY_CODE = "BT"
COUNTRY_NAME = "Bhutan"

