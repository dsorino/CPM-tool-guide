# Datastore API

This repository provides the programming interface for accessing and managing
data in the central datastore. It includes functions for retrieving economic
time series, submitting new data, and mapping between different data formats
used across the forecasting system.