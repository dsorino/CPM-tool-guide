r"""
Mapping utilities with support for named placeholders.

This module provides functionality to read/write mappings from CSV files
and expand named placeholders (e.g., ${COUNTRY}) with provided values.
"""


#[

from __future__ import annotations

# Standard library imports
import csv
import re

#]


__all__ = (
    "read_mapping_from_csv_file",
    "write_mapping_to_csv_file",
    "expand_placeholders",
)


def expand_placeholders(
    text: str,
    attributes: dict[str, str],
) -> str:
    r"""
    Expand named placeholders in text using the provided attributes.

    Placeholders should be in the format ${PLACEHOLDER_NAME}.

    Args:
        text: Text containing placeholders to expand
        attributes: Dictionary mapping placeholder names to attribute values

    Returns:
        Text with placeholders replaced by their corresponding values

    Example:
        >>> expand_placeholders("data_${COUNTRY}_2023", {"COUNTRY": "US"})
        'data_US_2023'
    """
    def replace_func(match):
        placeholder_name = match.group(1)
        if placeholder_name in attributes:
            return str(attributes[placeholder_name])
        else:
            # Keep the original placeholder if no replacement found
            return match.group(0)

    # Pattern to match ${PLACEHOLDER_NAME}
    pattern = r'\$\{([^}]+)\}'
    return re.sub(pattern, replace_func, text)


def read_mapping_from_csv_file(
    file_name: str,
    attributes: dict[str, str] | None = None,
) -> dict[str, str]:
    r"""
    Read variable-to-storage-key mapping from a CSV file.

    Args:
        file_name: Path to the CSV file containing the mapping
        attributes: Optional dictionary for expanding placeholders in storage keys

    Returns:
        Dictionary mapping variable names to storage keys (with placeholders expanded)
    """
    mapping: dict[str, str] = {}
    with open(file_name, mode="rt", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            variable_name = row["variable_name"].strip()
            storage_key = row["storage_key"].strip()
            if not variable_name or not storage_key:
                continue
            if variable_name.startswith("#") or storage_key.startswith("#"):
                continue
            mapping[variable_name] = storage_key

    # Expand placeholders if attributes are provided
    if attributes:
        mapping = {
            var: expand_placeholders(key, attributes)
            for var, key in mapping.items()
        }

    return mapping


def write_mapping_to_csv_file(
    mapping: dict[str, str],
    file_name: str,
) -> None:
    r"""
    """
    with open(file_name, mode="wt", encoding="utf-8", newline="") as f:
        fieldnames = ("variable_name", "storage_key", )
        writer = csv.DictWriter(f, fieldnames=fieldnames, )
        writer.writeheader()
        for variable_name, storage_key, in mapping.items():
            writer.writerow(
                {
                    "variable_name": variable_name,
                    "storage_key": storage_key,
                }
            )


