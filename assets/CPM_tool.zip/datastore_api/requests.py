r"""
"""


#[

from __future__ import annotations

# Third-party imports
import datapie as dp

# Local imports
import datastore
from . import interfaces as _interfaces

#]


__all__ = (
    "request",
    "apply_inverse_mapping",
)


def request(
    mapping: dict[str, str],
) -> dp.Databox:
    r"""
    """
    storage_keys = tuple(mapping.values())
    response_db = request_records(storage_keys=storage_keys, )
    apply_inverse_mapping(
        response_db=response_db,
        mapping=mapping,
    )
    return response_db


def request_records(
    storage_keys: Iterable[str] | None = None,
) -> dp.Databox:
    r"""
    """
    metadata_targets = tuple(
        _interfaces.metadata_from_storage_key(i)
        for i in storage_keys
    ) if storage_keys is not None else None
    #
    store = _interfaces.create_data_store()
    store.read_records_from_csv_file(file_name=datastore.DATA_FILE_PATH, )
    records, missing, = store.request_records(
        metadata_targets=metadata_targets,
        return_missing=True,
    )
    if missing:
        raise ValueError(f"Requested records are missing: {missing!r}")
    return _interfaces.databox_from_records(records, )


def apply_inverse_mapping(
    response_db: dp.Databox,
    mapping: dict[str, str] | None = None,
) -> None:
    r"""
    """
    if mapping is None:
        return
    inverse_mapping = {
        storage_key: variable_name
        for variable_name, storage_key, in mapping.items()
    }
    response_db.rename(
        target_names=lambda storage_key: inverse_mapping[storage_key],
    )
    for storage_key, variable_name in inverse_mapping.items():
        response_db[variable_name].set_description(storage_key, )

