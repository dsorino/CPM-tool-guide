r"""
"""


#[

from __future__ import annotations

# Standard library imports
import csv
from collections import namedtuple

# Typing imports
import math
from collections.abc import Iterable

# Third-party imports
import datapie as dp
import timescroll as ts
from timescroll import Store, Record, Schema

#]


__all__ = (
    "databox_from_records",
    "records_from_databox",
    "storage_key_from_metadata",
    "metadata_from_storage_key",
    "MetaData",
    "SourceInfo",
)


SCHEMA = Schema(
    origin=None,
    geography=None,
    concept=None,
    frequency=("enumeration", ("Y", "M", "Q", )),
    seasonal=("enumeration", ("SA", "NSA", "X", )),
)

SOURCE_FIELDS = ("provider", "request", )

MetaData = ts.build_metadata_class(schema=SCHEMA, )
SourceInfo = namedtuple("Source", SOURCE_FIELDS, )


def create_data_store() -> Store:
    r"""
    """
    return Store(schema=SCHEMA, )


def databox_from_records(records: Iterable, ) -> dp.Databox:
    r"""
    """
    return dp.Databox({
        storage_key_from_metadata(i.metadata, ): series_from_record(i, )
        for i in records
    })


def records_from_databox(
    databox: dp.Databox,
    storage_keys: Iterable[str] | None = None,
    variant: int = 0,
) -> Iterable[Record]:
    r"""
    """
    #[
    if storage_keys is None:
        storage_keys = databox.keys()
    records = []
    for k in storage_keys:
        metadata = metadata_from_storage_key(k, )
        series = databox[k]
        start_period = series.start.to_sdmx_string()
        values = series.get_values(..., variant, )
        values = tuple(
            i if not math.isnan(i) else None
            for i in values
        )
        record = Record(
            metadata=metadata,
            start_period=start_period,
            observations=values,
        )
        records.append(record, )
    return records
    #]


def storage_key_from_metadata(
    metadata: MetaData,
) -> str:
    r"""
    """
    return ".".join(metadata, )


def metadata_from_storage_key(
    storage_key: str,
) -> MetaData:
    r"""
    """
    return MetaData(*storage_key.split("."), )


def series_from_record(
    record: Record,
) -> dp.Series:
    r"""
    """
    #[
    frequency = dp.Frequency.from_letter(record.metadata.frequency, )
    start_period = dp.Period.from_sdmx_string(record.start_period, frequency=frequency, )
    return dp.Series(
        start=start_period,
        values=record.observations,
    )
    #]

