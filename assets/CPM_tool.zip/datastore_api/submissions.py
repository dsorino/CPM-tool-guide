r"""
"""


#[

from __future__ import annotations

# Third-party imports
import datapie as dp

# Local imports
import datastore
from . import interfaces as _interfaces

#]


__all__ = (
    "submit",
    "apply_mapping",
)


def submit(
    source_db: dp.Databox,
    mapping: dict[str, str],
) -> None:
    r"""
    """
    variable_names = tuple(mapping.keys())
    submission_db = source_db.shallow(
        source_names=variable_names,
        target_names=lambda n: mapping[n],
        strict_names=True,
    )
    storage_keys = tuple(mapping.values())
    submit_records(submission_db, storage_keys, )
    for variable_name, storage_key, in mapping.items():
        submission_db[storage_key].set_description(variable_name)
    return submission_db


def submit_records(
    submission_db: dp.Databox,
    storage_keys: Iterable[str],
) -> None:
    r"""
    """
    records = _interfaces.records_from_databox(submission_db, storage_keys, )
    store = _interfaces.create_data_store()
    store.read_records_from_csv_file(file_name=datastore.DATA_FILE_PATH, )
    store.submit_records(records, )
    store.write_records_to_csv_file(file_name=datastore.DATA_FILE_PATH, )


def apply_mapping(
    submission_db: dp.Databox,
    mapping: dict[str, str] | None = None,
) -> None:
    r"""
    """
    if mapping is None:
        return
    submission_db.rename(
        target_names=lambda variable_name: mapping[variable_name],
    )

