# Operational Instructions

This document provides step-by-step instructions for operating the ADB
macroeconomic forecasting system. The workflow follows a three-stage process:
data updates, external environment forecasts, and focus country forecasts.

## Overview of Operations

The ADB system operates in a sequential three-stage workflow with critical
sequencing dependencies within each stage:

1. **Data Update** - Refresh all economic data from external sources


2. **External Environment Forecasts** - Prepare forecasts in strict sequence:

   - US first (main reference economy)
   - CN, JP, EA second (require US CPI for real exchange rate gaps)


3. **Focus Country Forecasts** - Generate projections with hierarchy:

   - PH, IN can run after external environment is complete  
   - BT requires IN completion (currency peg dependency)


Each stage must be completed before proceeding to the next, and specific
sequencing within stages is mandatory to ensure data consistency and
proper model dependencies.

## Execution Flowchart

The complete execution sequence must follow this order:

```
1. Data Update
   ↓
2a. US External Economy (must run first)
   ↓  
2b. CN, JP, EA External Economies (can run in parallel after US completes)
   ↓
3a. PH, IN Focus Countries (can run in parallel after all external complete)
   ↓
3b. BT Focus Country (can only run after IN completes)
```

**Critical Dependencies:**
- CN, JP, EA require US CPI projections for real exchange rate gap calculations
- All focus countries require complete external environment (US, CN, JP, EA)
- BT requires India's projections due to currency peg arrangement

## Stage 1: Update Data

### Purpose
Refresh the central datastore with the latest economic data from FRED, IMF,
and other external sources.

### Actions
1. Navigate to the datastore_pumps module
2. Execute `update_all.py` to refresh data from all sources
3. Verify data completeness in the datastore
4. Check for any missing or problematic series

### Key Files
- `datastore_pumps/update_all.py` - Main data update script
- `datastore/data.csv` - Updated central data repository

## Stage 2: External Environment Forecasts

### Purpose  
Generate forecasts for the major economies that provide external conditions
for focus country projections. The sequencing within this stage is critical
due to model dependencies.

### Sequencing Requirements

#### Step 2.1: Main Reference External Economy
- **United States (us/)** - MUST be executed first
- The US serves as the main reference external economy
- US CPI projections are required for computing real exchange rate gaps
  against the USD for other external economies

#### Step 2.2: Other External Economies (Sequential or Parallel)
- **China (cn/)**  
- **Japan (jp/)**
- **Euro Area (ea/)**
- These can only be executed AFTER the US projections are complete
- They depend on US CPI data to compute real exchange rate gaps against USD

### Actions for Each External Country
1. Review forecast workflow attributes in `attributes.json`
2. Run `create_model.py` to build and calibrate the model
3. Validate model outputs and save results for focus country use
4. Ensure US projections are available before running CN, JP, and EA

### Key Files per Country
- `attributes.json` - Forecast workflow configuration
- `create_model.py` - Model creation and calibration script
- `data_files/` - Country-specific data inputs

## Stage 3: Focus Country Forecasts

### Purpose
Generate projections for the countries of primary interest, incorporating
external environment conditions from Stage 2. Focus countries require
complete external environment projections and follow a specific hierarchy
due to exchange rate regime dependencies.

### Prerequisites
- ALL external environment forecasts (US, CN, JP, EA) MUST be complete
- External projections provide foreign assumptions: demand (GDP gaps), 
  real exchange rate gaps, import price pressures, and US interest rates

### Sequencing Requirements

#### Step 3.1: Independent Focus Countries (Parallel Execution Possible)
- **Philippines (ph/)**
- **India (in/)**  

#### Step 3.2: Exchange Rate Peg Dependent Countries
- **Bhutan (bt/)** - MUST be executed AFTER India
- Bhutan maintains a currency peg to India
- Requires India's projection to be completed first due to exchange rate regime

### Actions for Each Focus Country
1. Ensure ALL external environment forecasts are complete
2. For Bhutan: Additionally ensure India's projection is complete
3. Update forecast workflow attributes in `attributes.json`  
4. Run `create_model.py` incorporating external conditions
5. Generate projection reports and visualizations
6. Validate forecast consistency with external assumptions

### Key Files per Country
- `attributes.json` - Country-specific forecast configuration
- `create_model.py` - Model creation with external linkages
- `data_files/` - Domestic economic data

## Reporting and Documentation

### Final Actions
1. Generate reports using `reporting_infrastructure/`
2. Create charts and visualization packages
3. Document key forecast assumptions
4. Archive model runs and maintain version control

## Quality Control

Throughout all stages:
- Verify data completeness and consistency
- Check model convergence and stability
- Validate forecast reasonableness
- Ensure proper documentation of assumptions

## Troubleshooting

Common issues:
- Data feed failures: Check source availability and connections
- Model convergence: Review parameter bounds and initial conditions
- Inconsistent forecasts: Verify external environment assumptions
- Missing dependencies: Ensure all packages are updated

This workflow ensures systematic production of consistent macroeconomic
forecasts across all countries in the ADB system.
