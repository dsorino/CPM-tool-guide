# Documentation

This repository contains documentation for the multi-country macroeconomic
forecasting system.

## Contents

- **[Project Overview](project_overview.md)**: System architecture and
  component descriptions
- **[Setup Instructions](setup_instructions.md)**: Environment configuration
  and installation guide
- **[Operational Instructions](operational_instructions_for_country_models.md)**:
  Step-by-step workflow for running country forecasts
- **[Sequencing Instructions](operational_instructions_for_sequencing.md)**:
  Coordination across multiple models
- **[Foreign Demand Methodology](foreign_demand_proxy_methodology.md)**:
  External sector modeling approach
- **[Requirements](requirements.txt)**: Python package dependencies