
## Main design and implementation choices


* Responsibilities and ownership

* Platform and orchestration

* Data warehouse

* Model templating

* Data production flows

* Workflows, processes and operation

* Versioning, auditability, reproducibility


------------------------------------------------


## Responsibilities and ownership

* Multiple components

* Development responsibilities

* Maintenance responsibilities

* Operation responsibilities


------------------------------------------------


## Platform and orchestration

Choose a platform that supports / can host

* SQL database
* Version control (git)
* Basic orchestration (parameterized shell scripts)
* Maybe containerization
* Basic UI elements


------------------------------------------------


## Data warehouse

* SQL
* Either a platform subscription or a self-hosted solution
* Cloud or on the premises
* Developed as an integral part of the project or delegated to a data
  engineering team


------------------------------------------------


## Model templating

* A template for the model code
* Placeholders/parameters for the variable parts
* Possibly a number of templates for different types of economies
* Standardized operations and reporting


------------------------------------------------

## Data production flows

* External sources and data acquisition (data pumps)
* Internal assumptions (e.g. external economies)
* Access to internally produced data


--------------------------------------------------


## Workflows, processes and operation

* Workflows (processes) as repositories
* End-to-end versus loop-out workflows
* Workflow (process) triggering (manual, scheduled, event-based)
* Judgmental data input methods


--------------------------------------------------

## Versioning, auditability, reproducibility

* Version and audit data, codebase and production workflows
* Leverage **git** for versioning (branching, tagging, etc.)

