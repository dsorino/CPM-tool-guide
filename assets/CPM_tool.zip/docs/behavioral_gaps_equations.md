# Behavioral Gaps Model - Mathematical Equations


This document presents the mathematical equations from the behavioral gaps 
component of the ADB macroeconomic model, typeset using LaTeX notation. This 
is a semi-structural gap model that captures the cyclical behavior of 
macroeconomic variables around their trend levels through reduced-form 
behavioral relationships.

## Table of Contents

- [Aggregate GDP Gap](#aggregate-gdp-gap)
- [GDP Components Gap Equations](#gdp-components-gap-equations)
- [Short-term GDP Components](#short-term-gdp-components)
- [External Variables Gaps](#external-variables-gaps)
- [Price and Inflation Dynamics](#price-and-inflation-dynamics)
- [Interest Rate Equations](#interest-rate-equations)
- [Exchange Rate Equations](#exchange-rate-equations)
- [Notation](#notation)

## Aggregate GDP Gap

The aggregate GDP gap equation captures how real output deviates from its trend 
level based on key macroeconomic conditions. It responds to real interest rate 
gaps, effective external competitiveness, terms of trade, and external demand 
conditions.

$$\begin{align*}
\log \tilde{\mathit{gdp}}_t &= c_0 \, \log \tilde{\mathit{gdp}}_{t-1} - c_1 \, 
\tilde{\mathit{r}\imath}_t + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t \\
&\quad + c_3 \, \log \tilde{\mathit{tot}}_t + c_4 \, \log 
\tilde{\mathit{gdp}^{\star \mathrm{eff}}}_t \\
&\quad + \varepsilon^{\mathrm{ann}}_{\mathit{gdp},t} + 
\varepsilon_{\mathit{gdp},t} + \varepsilon^{\mathrm{bu}}_{\mathit{gdp},t}
\end{align*}$$

## GDP Components Gap Equations

These equations model the cyclical behavior of GDP expenditure components 
around 
their trend levels. Each component responds to common macroeconomic drivers 
while incorporating top-down consistency adjustments from the aggregate GDP 
identity.

### Private Consumption Gap

Private consumption gaps reflect household spending decisions relative to 
trend, 
influenced by borrowing costs, external competitiveness, and terms of trade 
effects.

$$\begin{align*}
\log \tilde{\mathit{cpr}}_t &= c_0 \, \log \tilde{\mathit{cpr}}_{t-1} - c_1 \, 
\tilde{\mathit{r}\imath}_t + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t \\
&\quad + c_3 \, \log \tilde{\mathit{tot}}_t + 
\varepsilon^{\mathrm{ann}}_{\mathit{cpr},t} + \varepsilon_{\mathit{cpr},t} \\
&\quad + \left[ \frac{\mathit{cpr}}{\mathit{gdp}} \right]^{\mathrm{ss}} \, 
\varepsilon^{\mathrm{td}}_{\mathit{gdp},t}
\end{align*}$$

### Government Consumption Gap

Government consumption gaps capture discretionary fiscal policy effects and 
automatic stabilizers that cause public spending to deviate from its trend path.

$$\begin{align*}
\log \tilde{\mathit{cgg}}_t &= c_0 \, \log \tilde{\mathit{cgg}}_{t-1} - c_1 \, 
\tilde{\mathit{r}\imath}_t + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t \\
&\quad + c_3 \, \log \tilde{\mathit{tot}}_t + 
\varepsilon^{\mathrm{ann}}_{\mathit{cgg},t} + \varepsilon_{\mathit{cgg},t} \\
&\quad + \left[ \frac{\mathit{cgg}}{\mathit{gdp}} \right]^{\mathrm{ss}} \, 
\varepsilon^{\mathrm{td}}_{\mathit{gdp},t}
\end{align*}$$

### Fixed Capital Formation Gap

Investment gaps reflect business investment decisions driven by financing 
conditions, competitiveness effects, and terms of trade impacts on capital 
goods prices.

$$\begin{align*}
\log \tilde{\mathit{fcf}}_t &= c_0 \, \log \tilde{\mathit{fcf}}_{t-1} - c_1 \, 
\tilde{\mathit{r}\imath}_t + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t \\
&\quad + c_3 \, \log \tilde{\mathit{tot}}_t + 
\varepsilon^{\mathrm{ann}}_{\mathit{fcf},t} + \varepsilon_{\mathit{fcf},t} \\
&\quad + \left[ \frac{\mathit{fcf}}{\mathit{gdp}} \right]^{\mathrm{ss}} \, 
\varepsilon^{\mathrm{td}}_{\mathit{gdp},t}
\end{align*}$$

### Goods and Services Export Gap

Export gaps capture the competitiveness and external demand effects on trade 
performance, with no direct interest rate sensitivity reflecting institutional 
export financing.

$$\log \tilde{\mathit{xgs}}_t = c_0 \, \log \tilde{\mathit{xgs}}_{t-1} 
    + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t
    + c_3 \, \log \tilde{\mathit{tot}}_t 
    + \varepsilon^{\mathrm{ann}}_{\mathit{xgs},t} 
    + \varepsilon_{\mathit{xgs},t} 
    + \left[ \frac{\mathit{xgs}}{\mathit{gdp}} \right]^{\mathrm{ss}} \, 
\varepsilon^{\mathrm{td}}_{\mathit{gdp},t}$$

### Goods and Services Import Gap

Import gaps respond to domestic competitiveness conditions, reflecting how 
external price competitiveness affects import demand relative to trend.

$$\log \tilde{\mathit{mgs}}_t = c_0 \, \log \tilde{\mathit{mgs}}_{t-1} 
    + c_2 \, \log \tilde{\mathit{re}^{\mathrm{eff}}}_t
    + \varepsilon^{\mathrm{ann}}_{\mathit{mgs},t} 
    + \varepsilon_{\mathit{mgs},t} 
    - \left[ \frac{\mathit{mgs}}{\mathit{gdp}} \right]^{\mathrm{ss}} \, 
\varepsilon^{\mathrm{td}}_{\mathit{gdp},t}$$

## Short-term GDP Components

These components capture the more volatile elements of GDP that don't follow 
standard behavioral relationships, typically modeled as mean-reverting 
processes 
around their trend levels.

### Change in Business Inventories to GDP

Inventory accumulation follows a mean-reverting process around its trend, 
capturing the cyclical nature of business inventory management.

$$\left[ \frac{\mathit{cbi}}{\mathit{gdp}} \right]_t = c_0 \, \left[ 
\frac{\mathit{cbi}}{\mathit{gdp}} \right]_{t-1} 
    + (1 - c_0) \, \overline{\left[ \frac{\mathit{cbi}}{\mathit{gdp}} 
\right]}_t 
    + \varepsilon_{\left[ \frac{\mathit{cbi}}{\mathit{gdp}} \right],t}$$

### Statistical Discrepancy to GDP

The statistical discrepancy captures measurement errors and unobserved 
components in GDP accounting, modeled as a persistent but mean-reverting 
process.

$$\left[ \frac{\mathit{sdx}}{\mathit{gdp}} \right]_t = c_0 \, \left[ 
\frac{\mathit{sdx}}{\mathit{gdp}} \right]_{t-1} 
    + \varepsilon_{\left[ \frac{\mathit{sdx}}{\mathit{gdp}} \right],t}$$

## External Variables Gaps

These equations model the cyclical behavior of external economic conditions 
that 
affect domestic economic activity through trade and competitiveness channels.

### Terms of Trade Gap

Terms of trade gaps capture deviations in relative export-import prices from 
their equilibrium level, following a persistent autoregressive process.

$$\log \tilde{\mathit{tot}}_t = c_0 \, \log \tilde{\mathit{tot}}_{t-1} 
    + \varepsilon_{\mathit{tot},t}$$

### External Real GDP Gap

This represents economic slack in external economies excluding the US, 
capturing 
foreign demand conditions that affect domestic exports and competitiveness.

$$\log \tilde{\mathit{gdp}^{\star x}}_t = c_0 \, \log 
\tilde{\mathit{gdp}^{\star x}}_{t-1} 
    + \varepsilon_{\mathit{gdp}^{\star x},t} 
    + \tau_{\mathit{gdp}^{\star x},t}$$

### Effective External Real GDP Gap

A trade-weighted combination of US and non-US external GDP gaps, providing a 
comprehensive measure of foreign demand conditions relevant for domestic 
economic activity.

$$\log \tilde{\mathit{gdp}^{\star \mathrm{eff}}}_t = \omega_{\mathrm{us}} \, 
\log \tilde{\mathit{gdp}^{\star}}_t 
    + (1 - \omega_{\mathrm{us}}) \, \log \tilde{\mathit{gdp}^{\star x}}_t$$

### External Real Exchange Rate Gap

Captures deviations of external real exchange rates from equilibrium levels, 
representing competitiveness conditions in foreign markets excluding the US.

$$\log \tilde{\mathit{re}^{x}}_t = c_0 \, \log \tilde{\mathit{re}^{x}}_{t-1} 
    + \varepsilon_{\mathit{re}^{x},t} 
    + \tau_{\mathit{re}^{x},t}$$

### Effective External Real Exchange Rate Gap

A competitiveness measure that combines domestic real exchange rate effects 
with external real exchange rate conditions, weighted by trade importance.

$$\log \tilde{\mathit{re}^{\mathrm{eff}}}_t = \log \tilde{\mathit{re}}_t 
    - (1 - \omega_{\mathrm{us}}) \, \log \tilde{\mathit{re}^{x}}_t$$

## Price and Inflation Dynamics

These equations model inflation as driven by both demand-side pressures (output 
gaps) and supply-side factors (competitiveness effects), with forward-looking 
expectations playing a key role.

### Phillips Curve

The Phillips curve links inflation to economic slack and competitiveness 
effects, with expectations formed as a weighted average of forward-looking and 
backward-looking components.

$$\begin{align*}
4 \, \Delta \log \mathit{cp\imath}_t &= c_0 \, \cdot \, 4 \, \Delta \log 
\mathit{cp\imath}_{t-1} + (1 - c_0) \, \cdot \, 4 \, \Delta \log 
\mathit{cp\imath}^{\mathrm{ste}}_t \\
&\quad + c_1 \, \log \tilde{\mathit{gdp}}_t + c_2 \, \log 
\tilde{\mathit{re}^{\mathrm{eff}}}_t \\
&\quad + \varepsilon_{\Delta \log \mathit{cp\imath},t} + 
\varepsilon^{\mathrm{short}}_{\Delta \log \mathit{cp\imath},t} + \tau_{\Delta 
\log \mathit{cp\imath},t}
\end{align*}$$

where the short-lived shock and tune components follow:

$$\varepsilon^{\mathrm{short}}_{\Delta \log \mathit{cp\imath},t} = 
    \varepsilon^{\mathrm{aux}}_{\mathrm{short},t} 
    - c_x \, \varepsilon^{\mathrm{aux}}_{\mathrm{short},t-1}$$

$$\tau_{\Delta \log \mathit{cp\imath},t} = \tau^{\mathrm{aux}}_t 
    - (c_x - 0.1) \, \tau^{\mathrm{aux}}_{t-1}$$

### CPI Short-term Expectations

Inflation expectations combine forward-looking rational expectations with 
adaptive elements based on the underlying inflation trend.

$$\begin{align*}
4 \, \Delta \log \mathit{cp\imath}^{\mathrm{ste}}_t &= c_1 \, \cdot \, 4 \, 
\Delta \log \mathit{cp\imath}_{t+1} \\
&\quad + (1 - c_1) \, \cdot \, 4 \, \Delta \log \overline{\mathit{cp\imath}}_t
\end{align*}$$

## Interest Rate Equations

These equations model monetary policy transmission through interest rate 
setting, incorporating both systematic policy responses and discretionary 
policy actions.

### Nominal Interest Rate

The policy rate adjusts gradually toward a target level that incorporates the 
trend rate plus a monetary policy reaction component, allowing for policy 
inertia.

$$i_t = c_0 \, i_{t-1} 
    + (1 - c_0) \, (\overline{\mathit{\imath}}_t + \mathit{mpr}_t) 
    + \varepsilon_{i,t} 
    + \tau_{i,t}$$

### Monetary Policy Reaction Term

The systematic component of monetary policy that responds to deviations of 
expected inflation from target, output gaps, and exchange rate competitiveness 
effects.

$$\begin{align*}
\mathit{mpr}_t &= c_1 \, (\Delta \log \mathit{cp\imath}_{t+3} - 4 \, \Delta 
\log \overline{\mathit{cp\imath}}_t) \\
&\quad + c_2 \, \log \tilde{\mathit{gdp}}_t + c_3 \, \log \tilde{\mathit{re}}_t
\end{align*}$$

## Exchange Rate Equations

These equations model exchange rate determination through interest rate 
differentials and expectations, incorporating both financial market arbitrage 
conditions and expectation formation.

### Uncovered Interest Parity Condition

Links domestic and foreign interest rates through expected exchange rate 
changes 
and a risk premium, allowing for deviations from perfect capital mobility.

$$\begin{align*}
i_t - i^\star_t &= 4 \, (\log e^{\mathrm{ste}}_t - \log e_t) + \mathit{d\imath 
sp}_t \\
&\quad + \varepsilon_{e,t} + \tau_{e,t}
\end{align*}$$

### Nominal Exchange Rate Short-term Expectations

Exchange rate expectations combine forward-looking market expectations with 
adaptive elements based on recent exchange rate trends.

$$\begin{align*}
\log e^{\mathrm{ste}}_t &= c_1 \, \log e_{t+1} + (1 - c_1) \, \log e_{t-1} \\
&\quad + (1 - c_1) \, \cdot \, \frac{1}{2} \, \cdot \, 4 \, \Delta \log 
\overline{e}_t
\end{align*}$$

### UIP Disparity Gap

Captures persistent deviations from uncovered interest parity, representing 
risk premia and market sentiment effects that cause exchange rates to deviate 
from fundamental values.

$$\tilde{\mathit{d\imath sp}}_t = c_0 \, \tilde{\mathit{d\imath sp}}_{t-1} 
    + \varepsilon_{\mathit{d\imath sp},t} 
    + c_1 \, \tau_{\mathit{e},t}$$

## Notation

- $\tilde{x}$ denotes gaps (proportional deviations from trend)
- $\overline{x}$ denotes trends
- $\Delta \log x$ denotes log growth rates (Q/Q)
- $\star$ denotes external variables (ending in "w")
- $\mathrm{eff}$ denotes effective external variables (ending in "wx")
- $x$ denotes external variables excluding US (ending in "x")
- $\varepsilon_{x,t}$ denotes structural shocks
- $\tau_{x,t}$ denotes simulation tunes
- $\left[ \frac{\cdot}{\cdot} \right]^{\mathrm{ss}}$ denotes steady-state ratios
- $\omega_{x}$ denotes trade weights
- $c_0, c_1, c_2, \ldots$ denote behavioral parameters
