# ADB Macroeconomic Model - Variable Documentation

This document provides a comprehensive list of all variables used in the ADB macroeconomic projection model, organized by economic concept and variable type.

## 1. Real GDP and Output Variables

### Core GDP Variables
| Variable | Description |
|----------|-------------|
| `gdp` | Real GDP |
| `roc_gdp` | Real GDP, Q/Q |
| `gdp_tnd` | Real GDP trend |
| `roc_gdp_tnd` | Real GDP trend, Q/Q |
| `gdp_gap` | Real GDP gap |
| `ann_gdp` | Annual moving average of real GDP |
| `aux_gdp_tnd` | Auxiliary variable for real GDP trend, Q/Q |

### GDP Components - Private Consumption
| Variable | Description |
|----------|-------------|
| `cpr` | Real private consumption |
| `cpr_tnd` | Real private consumption trend |
| `cpr_gap` | Real private consumption gap |
| `cpr_to_gdp` | Real private consumption to GDP |
| `cpr_to_gdp_tnd` | Real private consumption to GDP trend |
| `ann_cpr` | Annual moving average of real private consumption |
| `roc4_ann_cpr` | Real private consumption, Y/Y annual moving average |

### GDP Components - Government Consumption
| Variable | Description |
|----------|-------------|
| `cgg` | Real government consumption |
| `cgg_tnd` | Real government consumption trend |
| `cgg_gap` | Real government consumption gap |
| `cgg_to_gdp` | Real government consumption to GDP |
| `cgg_to_gdp_tnd` | Real government consumption to GDP trend |
| `ann_cgg` | Annual moving average of real government consumption |
| `roc4_ann_cgg` | Real government consumption, Y/Y annual moving average |

### GDP Components - Investment
| Variable | Description |
|----------|-------------|
| `fcf` | Real fixed capital formation |
| `fcf_tnd` | Real fixed capital formation trend |
| `fcf_gap` | Fixed capital formation gap |
| `fcf_to_gdp` | Real fixed capital formation to GDP |
| `fcf_to_gdp_tnd` | Real fixed capital formation to GDP trend |
| `ann_fcf` | Annual moving average of real fixed capital formation |
| `roc4_ann_fcf` | Real fixed capital formation, Y/Y annual moving average |

### GDP Components - Trade
| Variable | Description |
|----------|-------------|
| `xgs` | Export of goods and services |
| `xgs_tnd` | Export of goods and services trend |
| `xgs_gap` | Goods and services export gap |
| `xgs_to_gdp` | Export of goods and services to GDP |
| `xgs_to_gdp_tnd` | Export of goods and services to GDP trend |
| `ann_xgs` | Annual moving average of export of goods and services |
| `roc4_ann_xgs` | Export of goods and services, Y/Y annual moving average |
| `mgs` | Import of goods and services |
| `mgs_tnd` | Import of goods and services trend |
| `mgs_gap` | Goods and services import gap |
| `mgs_to_gdp` | Import of goods and services to GDP |
| `mgs_to_gdp_tnd` | Import of goods and services to GDP trend |
| `ann_mgs` | Annual moving average of import of goods and services |
| `roc4_ann_mgs` | Import of goods and services, Y/Y annual moving average |

### GDP Components - Other
| Variable | Description |
|----------|-------------|
| `cbi_to_gdp` | Change in business inventories to GDP |
| `cbi_to_gdp_tnd` | Change in business inventories to GDP trend |
| `ann_cbi_to_gdp` | Change in business inventories to GDP, annual moving average |
| `sdx_to_gdp` | Statistical discrepancy to GDP |
| `ann_sdx_to_gdp` | Statistical discrepancy to GDP, annual moving average |

### GDP Identity Variables
| Variable | Description |
|----------|-------------|
| `gdp_ident` | Real GDP by bottom-up identity |
| `gdp_resid` | Residual in real GDP by bottom-up identity |

## 2. Price and Inflation Variables

### Domestic Prices
| Variable | Description |
|----------|-------------|
| `cpi` | Consumer price index |
| `roc_cpi` | CPI Q/Q |
| `roc4_cpi` | CPI Y/Y |
| `roc_cpi_tnd` | CPI Q/Q trend |
| `roc_cpi_ste` | CPI Q/Q short-term expectations |

### Terms of Trade
| Variable | Description |
|----------|-------------|
| `tot` | Terms of trade |
| `tot_tnd` | Terms of trade trend |
| `tot_gap` | Terms of trade gap |
| `ann_tot` | Annual moving average of terms of trade |

## 3. Interest Rate Variables

### Domestic Interest Rates
| Variable | Description |
|----------|-------------|
| `i` | Nominal interest rate |
| `i_tnd` | Nominal interest rate trend |
| `ri` | Real interest rate |
| `ri_tnd` | Real interest rate trend |
| `ri_gap` | Real interest rate gap |
| `mpr` | Monetary policy reaction term |

### External Interest Rates
| Variable | Description |
|----------|-------------|
| `iw` | External nominal interest rate |
| `iw_tnd` | External nominal interest rate trend |
| `riw` | External real interest rate |
| `riw_tnd` | External real interest rate trend |
| `riw_gap` | External real interest rate gap |

## 4. Exchange Rate Variables

### Domestic Exchange Rates
| Variable | Description |
|----------|-------------|
| `e` | Nominal exchange rate |
| `roc_e` | Nominal exchange rate, Q/Q |
| `roc_e_tnd` | Nominal exchange rate trend, Q/Q |
| `e_ste` | Nominal exchange rate, short-term expectations |
| `re` | Real exchange rate |
| `roc_re` | Real exchange rate, Q/Q |
| `re_tnd` | Real exchange rate trend |
| `roc_re_tnd` | Real exchange rate trend, Q/Q |
| `re_gap` | Real USD exchange rate gap |

### External Exchange Rates
| Variable | Description |
|----------|-------------|
| `ew` | Nominal USD exchange rate |
| `roc_ew` | Nominal USD exchange rate Q/Q |
| `roc_ew_tnd` | Nominal USD exchange rate Q/Q trend |
| `rex_gap` | External USD real exchange rate gap |
| `rewx_gap` | Effective external real exchange rate gap |

### UIP Variables
| Variable | Description |
|----------|-------------|
| `disp` | UIP disparity |
| `disp_tnd` | UIP disparity trend |
| `disp_gap` | UIP disparity gap |

## 5. External Sector Variables

### External GDP
| Variable | Description |
|----------|-------------|
| `gdpw` | External real GDP |
| `roc_gdpw` | External real GDP Q/Q |
| `apct_gdpw` | External real GDP Q/Q annualized percentage |
| `gdpw_tnd` | External real GDP trend |
| `roc_gdpw_tnd` | External real GDP trend, Q/Q |
| `gdpw_gap` | External real GDP gap |
| `gdpx_gap` | External real GDP gap (excluding US) |
| `gdpwx_gap` | Effective external real GDP gap |

### External Annual Variables
| Variable | Description |
|----------|-------------|
| `ann_gdpw` | Annual moving average of external real GDP |
| `roc4_ann_gdpw` | External real GDP, Y/Y annual moving average |

### External Prices
| Variable | Description |
|----------|-------------|
| `cpiw` | External consumer price index |
| `roc_cpiw` | External CPI Q/Q |
| `apct_cpiw` | External CPI Q/Q annualized percentage |
| `roc_cpiw_tnd` | External CPI Q/Q trend |
| `roc_cpiw_ste` | Short-term expectations for external CPI Q/Q |

## 6. Auxiliary and Technical Variables

### Shock Auxiliary Variables
| Variable | Description |
|----------|-------------|
| `aux_shk_roc_cpi_short` | Auxiliary variable for short-lived shock on CPI Q/Q |
| `aux_tune_roc_cpi` | Auxiliary variable for tune on CPI Q/Q |
| `aux_shk_roc_cpiw_short` | Auxiliary variable for short-lived shock to external CPI Q/Q |
| `aux_tune_roc_cpiw` | Auxiliary variable for tune on external CPI Q/Q |
| `aux_shk_gdpw_tnd` | Auxiliary variable for shock to external real GDP trend, Q/Q |

### Annual Tune Variables (Template-Generated)
| Variable | Description |
|----------|-------------|
| `aux_shk_ann_gdp` | Auxiliary variable for annual shock to real GDP |
| `impact_shk_ann_gdp` | Impact of annual shock on real GDP |
| `aux_shk_ann_cpr` | Auxiliary variable for annual shock to private consumption |
| `impact_shk_ann_cpr` | Impact of annual shock on private consumption |
| `aux_shk_ann_cgg` | Auxiliary variable for annual shock to government consumption |
| `impact_shk_ann_cgg` | Impact of annual shock on government consumption |
| `aux_shk_ann_fcf` | Auxiliary variable for annual shock to fixed capital formation |
| `impact_shk_ann_fcf` | Impact of annual shock on fixed capital formation |
| `aux_shk_ann_xgs` | Auxiliary variable for annual shock to exports |
| `impact_shk_ann_xgs` | Impact of annual shock on exports |
| `aux_shk_ann_mgs` | Auxiliary variable for annual shock to imports |
| `impact_shk_ann_mgs` | Impact of annual shock on imports |
| `aux_shk_ann_gdpw` | Auxiliary variable for annual shock to external GDP |
| `impact_shk_ann_gdpw` | Impact of annual shock on external GDP |

## 7. Observable Variables (Measurement Equations)

### Quarterly Observables
| Variable | Description |
|----------|-------------|
| `obs_gdp` | Real GDP observations |
| `obs_cpr` | Private consumption observations |
| `obs_cgg` | Government consumption observations |
| `obs_fcf` | Fixed capital formation observations |
| `obs_xgs` | Goods and services export observations |
| `obs_mgs` | Goods and services import observations |
| `obs_cbi_to_gdp` | Change in business inventories observations |
| `obs_sdx_to_gdp` | Statistical discrepancy observations |

### Annual Observables
| Variable | Description |
|----------|-------------|
| `obs_ann_gdp` | Annual real GDP observations |
| `obs_ann_cpr` | Annual private consumption observations |
| `obs_ann_cgg` | Annual government consumption observations |
| `obs_ann_fcf` | Annual fixed capital formation observations |
| `obs_ann_xgs` | Annual goods and services export observations |
| `obs_ann_mgs` | Annual goods and services import observations |
| `obs_ann_cbi_to_gdp` | Annual change in business inventories observations |
| `obs_ann_sdx_to_gdp` | Annual statistical discrepancy observations |

### Other Observables
| Variable | Description |
|----------|-------------|
| `obs_tot` | Terms of trade observations |
| `obs_ann_tot` | Annual terms of trade observations |
| `obs_cpi` | CPI observations |
| `obs_e` | Nominal exchange rate observations |
| `obs_ew` | Nominal USD exchange rate observations |
| `obs_i` | Nominal interest rate observations |
| `obs_gdpx_gap` | External real GDP gap observations (excluding US) |
| `obs_rex_gap` | External USD real exchange rate gap observations |

### External Trend Observables
| Variable | Description |
|----------|-------------|
| `obs_gdpw` | External real GDP observations |
| `obs_gdpw_tnd` | External real GDP trend observations |
| `obs_cpiw` | External CPI observations |
| `obs_roc_cpiw_tnd` | External CPI Q/Q trend observations |
| `obs_iw` | External nominal interest rate observations |
| `obs_riw_tnd` | External real interest rate trend observations |

## Suggested Cleanup and Standardization

### 1. Naming Convention Issues

**Inconsistent Abbreviations:**
- `G&S` vs `gs` in descriptions vs variable names
- `Q/Q` vs `QoQ` (use `Q/Q` consistently)
- `Y/Y` vs `YoY` (use `Y/Y` consistently)

**Recommended Fixes:**
- Standardize "Goods and services" instead of mixing "G&S" and full form
- Use consistent temporal notation: `Q/Q` for quarter-over-quarter, `Y/Y` for year-over-year
- Fix typo: "Goods and servoices import gap" → "Goods and services import gap"

### 2. Description Standardization

**Current Issues:**
- Mix of "Real GDP" vs "real GDP" capitalization
- Inconsistent use of articles ("the", "a")
- Some descriptions are too verbose while others too brief

**Recommended Templates:**
- **Level variables**: "[Adjective] [concept]" (e.g., "Real GDP", "Nominal interest rate")
- **Growth rates**: "[Concept], Q/Q" or "[Concept], Y/Y"
- **Trends**: "[Concept] trend"
- **Gaps**: "[Concept] gap"
- **Ratios**: "[Numerator] to [denominator]"

### 3. Logical Grouping Improvements

**Trade Weights Missing Documentation:**
- `tw_us`, `tw_cn`, `tw_jp`, `tw_ea` should be documented in a separate parameters section

**External Variable Clarity:**
- Distinguish between "External (world)" vs "External (excluding US)" more clearly in descriptions
- Consider renaming `gdpx_gap` to `gdpx_ex_us_gap` for clarity

### 4. Missing Variable Descriptions

Some variables lack proper descriptions:
- `c0_disp_gap`, `c1_disp_gap`, `c1_e_ste` - these parameter names should have full descriptions following the pattern established for other parameters

### 5. Auxiliary Variable Organization

The numerous auxiliary variables for annual tunes could be better organized with a systematic naming convention that makes their purpose immediately clear from the variable name itself.


