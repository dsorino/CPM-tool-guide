# Operational Instructions for Country Model Forecasts

This document provides step-by-step instructions for running forecasts with
the country economic models in the forecasting system.

## Overview

The forecasting workflow consists of 9 sequential steps that must be executed
in order for each country model. All scripts should be run from the root
directory (`00adb/`) as Python modules.

## Country Models

### External Countries
- **us**: United States external model
- **cn**: China external model
- **jp**: Japan external model
- **ea**: Euro Area external model

### Focus Countries  
- **bt**: Bhutan domestic model
- **ph**: Philippines domestic model
- **in**: India domestic model

## Standard Workflow Steps

Execute these steps in sequence for each country model:

### 0. Configure Attributes (Before Starting)

Before running the forecast workflow, review and update the country's
`attributes.json` file.

**Key settings to review**:
- `"forecast_id"`: Unique identifier for this forecast round (e.g., "F1", "F2")
- `"external_forecast_id"`: For domestic models, ID of external forecasts to use
- `"forecast_end_period"`: End date for projections (e.g., "2027-Q4")
- `"history_end_period"`: Last period of historical data (e.g., "2025-Q4")
- `"history_start_period"`: Start of historical sample (e.g., "2010-Q1")

**Note**: These IDs are part of the datastore storage keys and must be
consistent across related models and forecast rounds.

### 1. Create Model
```bash
python -m {country}.create_model
```
Or in IPython console:
```python
run -m {country}.create_model
```

**Purpose**: Creates and calibrates the economic model with country-specific
parameters. Saves the model to a pickle file for use in subsequent steps.

### 2. Request Data from Datastore
```bash
python -m {country}.request_data
```

**Purpose**: Requests historical data from the central datastore based on the
input mapping configuration. Downloads raw data needed for model estimation
and forecasting.

### 3. Prepare History
```bash
python -m {country}.prepare_history
```

**Purpose**: Processes raw historical data from the datastore, applies
transformations, calculates derived variables, and prepares the dataset for
running the Kalman filter on the history.

### 4. Review Steady-State Calibration
```bash
python -m {country}.report_steady_calibration
```

**Purpose**: Generates charts and analysis of the model's steady-state
calibration against historical data. Review these outputs to validate that
the model's long-term equilibrium assumptions are appropriate before
proceeding with filtering and forecasting.

### 6. Filter History
```bash
python -m {country}.filter_history
```

**Purpose**: Applies statistical filters to separate trends from cyclical
components in the historical data. Creates filtered time series used as
inputs for forecasting.

### 7. Report Filter
```bash
python -m {country}.report_filter
```

**Purpose**: Generates charts and analysis of the filtered historical data to
validate the trend-cycle decomposition and review model inputs.

### 8. Simulate Forecast
```bash
python -m {country}.simulate_forecast
```

**Purpose**: Runs the economic model to generate forecasts. This is the step
that typically requires manual intervention for judgmental adjustments.

**Tunes on Annual Variables**: Open the `tune_files/annual_tunes.csv` (e.g. in
Excel), and enter the desired tunes on annual figures on the forecast horizon
(the forecast horizon is annotated by `1` in the `forecast_span` column). Note
that `roc` means the gross rate of change ($x_t / x_{t-1}$). All rates,
including the interest rates, are expressed as decimals. This means that an ROC
of $1.05$ corresponds to a 5% growth rate, and an interest rate of 0.05
corresponds to 5%. Remember to save the file and close it before running the
forecast.

**Manual Adjustments**: Look for the section marked with:
```python
#==============================================================
# Add judgmental adjustments here
#==============================================================
```
Here, you can add any extra manual adjustments to the forecast beyond the tunes
on annual variables.

### 9. Report Forecast
```bash
python -m {country}.report_forecast
```

**Purpose**: Creates charts, tables, and analytical outputs presenting the
forecast results in a standardized format for review and distribution.

### 10. Submit Forecast
```bash
python -m {country}.submit_forecast
```

**Purpose**: Uploads the forecast results to the central datastore, making
them available for use by other models and for final reporting.

## Execution Tips

1. **Run from root directory**: Always execute commands from the `00adb/`
   directory to ensure proper module imports.

2. **Check logs**: Each step produces logging output to monitor progress and
   identify any issues.

3. **Sequential execution**: Steps must be completed in order as each depends
   on outputs from the previous step.

4. **Judgmental review**: The simulate_forecast step is where analyst judgment
   is typically applied. Review the existing adjustments and modify as needed
   based on current economic conditions.

5. **Data validation**: Use the report steps (4, 7, and 9) to validate
   steady-state calibration, data quality, and forecast reasonableness before
   proceeding.

## Example: Complete Philippines Forecast

```bash
# First, configure forecast attributes in ph/attributes.json
python -m ph.create_model
python -m ph.request_data
python -m ph.prepare_history
python -m ph.report_steady_calibration
# Review steady-state calibration, then continue
python -m ph.filter_history
python -m ph.report_filter
# Review filter results, then continue
python -m ph.simulate_forecast
# Apply judgmental adjustments in simulate_forecast.py if needed
python -m ph.report_forecast
# Review forecast results, then submit
python -m ph.submit_forecast
```

## Example: Complete External Model (US) Forecast

```bash
# First, configure forecast attributes in us/attributes.json
python -m us.create_model
python -m us.request_data
python -m us.prepare_history
python -m us.report_steady_calibration
# Review steady-state calibration, then continue
python -m us.filter_history
python -m us.report_filter
python -m us.simulate_forecast
# Review and adjust GDP growth assumptions in simulate_forecast.py
python -m us.report_forecast
python -m us.submit_forecast
```
