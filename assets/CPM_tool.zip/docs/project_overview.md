# ADB Macroeconomic Forecasting System Overview

The ADB project is a comprehensive macroeconomic forecasting system designed
for multi-country external projections. It combines data management, model
infrastructure, country-specific projection workflows, and reporting
capabilities into an integrated Python-based framework.

## Data Management Components

**datastore/** - Central data repository hosting files in text (diffable) 
format for version control. Contains `data.csv` and extraction scripts.

**datastore_api/** - Standardized interfaces for data submission and retrieval
with components for API definitions, request handling, submissions, and field
mappings.

**datastore_pumps/** - Automated data collection from external sources 
including FRED and IMF feeds. Updates data via `update_all.py` from sources
like ANEA, MFS_IR, CPI, ER, and QNEA.

## Model Infrastructure

**model_infrastructure/** - Core modeling framework that builds models from
text-format source files. Contains `create_models.py` for model compilation
and `model_files/` directory with:

- `behavioral_gaps.model` - Behavioral relationships and gaps
- `trends_and_identities.model` - Long-term trends and identities
- `external.model` - External sector dynamics
- `measurement.model` - Data measurement equations
- `annual_tunes.model` - Annual calibration adjustments
- `external_annual_tunes.model` - External annual tuning parameters

## External Environment Models

**us/** - United States external environment (F1 forecast through 2027-Q4, 
history from 2010-Q1)

**cn/** - China external environment with model creation and data processing

**ea/** - Euro Area external environment (to be added)

These provide the external economic conditions and assumptions for the focus
country projections.

## Focus Country Models

**ph/** - Philippines projections using standardized workflow

**in/** - Indonesia projections with country-specific parameters

**bt/** - Bhutan projections with small economy modeling approach

These are the primary countries of interest that depend on the external
environment conditions.

Each country workflow includes `create_model.py`, `attributes.json` 
configuration, and data files.

## Reporting Infrastructure

**reporting_infrastructure/** - Standardized reporting and visualization with
projection charts, chart filtering utilities, and forecast visualization.

**html_docs/** & **docs/** - Project documentation and methodology notes.

## Supporting Packages

The system uses four Python packages from `~/iris-drive/`:

**irispie-package** - Core macroeconomic modeling engine providing model
solving, simulation, and analysis capabilities.

**datapie-package** - Time series and data management with dates, series,
databoxes, and charting utilities.

**timescroll-package** - Simple time-series oriented data store for efficient
storage and retrieval.

**macrotap-package** - External data source integration connecting to FRED,
IMF, and other providers.

## Architecture Flow

```
Data Sources (FRED, IMF) → datastore_pumps → datastore_api → datastore
    ↓
External Environment (US, CN, EA) → Focus Countries (PH, IN, BT)
    ↓
model_infrastructure → Model Files (.model text format)
    ↓
reporting_infrastructure → Charts & Reports
```

## Key Features

- Two-tier modeling: external environment and focus countries
- Multi-country support with standardized workflows
- Automated data management from major economic sources
- Version control integration via text-based storage
- Modular design separating data, modeling, and reporting
- Human-readable .model files for easy editing and version control
- Consistent forecasting framework across countries
- Extensible architecture for new countries or data sources

## Getting Started

Standard workflow:
1. Configure forecast workflow attributes in `attributes.json`
2. Run `create_model.py` to build and calibrate models from text source files
3. Generate reports using reporting infrastructure
4. Data automatically maintained through datastore system

External environment models provide conditions for focus country projections,
ensuring consistent global assumptions across all forecasts.