# Trends and Identities Model - Mathematical Equations


This document presents the mathematical equations from the trends and 
identities 
component of the ADB macroeconomic model, typeset using LaTeX notation. This 
component defines the long-run trend behavior of key macroeconomic variables 
and establishes accounting identities that ensure internal consistency of the 
model framework.

**Important Note**: This model employs a **multiplicative trend-gap 
decomposition** 
for all variables, where each variable is expressed as the product of its trend 
and gap components. This approach differs from the more common additive 
decompositions (in logarithms) typically found in macroeconomic models, and 
ensures that gaps represent proportional deviations from trend levels.

## Table of Contents

- [Aggregate GDP Equations](#aggregate-gdp-equations)
- [GDP Components Trend and Identity 
Equations](#gdp-components-trend-and-identity-equations)
- [External Variables Trends](#external-variables-trends)
- [Price Level and Inflation Trends](#price-level-and-inflation-trends)
- [Interest Rate Equations](#interest-rate-equations)
- [Exchange Rate Equations](#exchange-rate-equations)
- [UIP Disparity Equations](#uip-disparity-equations)
- [Notation](#notation)
- [Mathematical Conventions](#mathematical-conventions)

## Aggregate GDP Equations

These equations define the trend-cycle decomposition of real GDP and establish 
the fundamental growth dynamics of the economy through stochastic trend 
specifications.

### Real GDP Trend-Gap Identity

The fundamental multiplicative decomposition where GDP equals the product of 
its 
trend and gap components:

$$\mathit{gdp}_t = \overline{\mathit{gdp}}_t \times \tilde{\mathit{gdp}}_t$$

### Real GDP Trend Growth

$$\begin{align*}
4 \, \Delta \log \overline{\mathit{gdp}}_t - 
\varepsilon_{\overline{\mathit{gdp}},t} &= 
c_0 \, (4 \, \Delta \log \overline{\mathit{gdp}}_{t-1} - 
\varepsilon_{\overline{\mathit{gdp}},t-1}) \\
&\quad + (1 - c_0) \, 4 \, \Delta \log \overline{\mathit{gdp}}^{\mathrm{ss}} \\
&\quad + \varepsilon_{\Delta \log \overline{\mathit{gdp}},t}
\end{align*}$$

### Annual Moving Average GDP

The annual moving average provides a model-based interpolation mechanism that 
allows incorporation of annual data observations. In Q4, these match exactly 
the annual figures, enabling the Kalman filter to handle mixed-frequency data 
and perform quarterly interpolation of annual observations.

$$\mathit{gdp}^{\mathrm{ann}}_t = \sum_{j=0}^{3} \mathit{gdp}_{t-j}$$

## GDP Components Trend and Identity Equations

These equations establish the long-run expenditure shares of GDP components and 
their trend-cycle decompositions, ensuring consistency with the aggregate GDP 
accounting identity.

### Component Trend-Gap Identities

Each GDP component follows the same multiplicative trend-gap decomposition:

For each component $\jmath \in \{\mathit{cpr}, \mathit{cgg}, \mathit{fcf}, 
\mathit{xgs}, \mathit{mgs}\}$:

$$\jmath_t = \overline{\jmath}_t \times \tilde{\jmath}_t$$

### Component Trend Definitions

$$\overline{\jmath}_t = \overline{\left[ \frac{\jmath}{\mathit{gdp}} \right]}_t 
\times \overline{\mathit{gdp}}_t$$

### Annual Moving Averages for Components

For each component $\jmath$, the annual moving average enables mixed-frequency 
estimation by exactly matching annual data in Q4 periods:

$$\jmath^{\mathrm{ann}}_t = \sum_{k=0}^{3} \jmath_{t-k}$$

### Component Share Trends

For $\jmath \in \{\mathit{cpr}, \mathit{cgg}, \mathit{fcf}, \mathit{xgs}\}$ 
(note that 
imports are **excluded** as they are determined residually):

$$\begin{align*}
\log \overline{\left[ \frac{\jmath}{\mathit{gdp}} \right]}_t &= 
c_0 \, \log \overline{\left[ \frac{\jmath}{\mathit{gdp}} \right]}_{t-1} \\
&\quad + (1 - c_0) \, \log \overline{\left[ \frac{\jmath}{\mathit{gdp}} 
\right]}^{\mathrm{ss}} \\
&\quad + \varepsilon_{\overline{\left[ \frac{\jmath}{\mathit{gdp}} \right]},t}
\end{align*}$$

### Bottom-up GDP Trend Identity

This identity ensures that the trend components sum to unity and **residually 
determines the import-to-GDP share**:

$$1 = \overline{\left[ \frac{\mathit{cpr}}{\mathit{gdp}} \right]}_t + 
\overline{\left[ \frac{\mathit{cgg}}{\mathit{gdp}} \right]}_t + 
\overline{\left[ \frac{\mathit{fcf}}{\mathit{gdp}} \right]}_t + 
\overline{\left[ \frac{\mathit{cbi}}{\mathit{gdp}} \right]}^{\mathrm{ss}} + 
\overline{\left[ \frac{\mathit{xgs}}{\mathit{gdp}} \right]}_t - 
\overline{\left[ \frac{\mathit{mgs}}{\mathit{gdp}} \right]}_t$$

**Important**: Unlike other GDP components, the import-to-GDP trend share 
$\overline{\left[ \frac{\mathit{mgs}}{\mathit{gdp}} \right]}_t$ is **not 
modeled 
separately**. It is determined residually from this identity to ensure 
accounting consistency. There is no independent autoregressive process or 
steady-state parameter for the import share - it adjusts endogenously to 
satisfy the GDP accounting constraint.

**Note on CBI and SDX trends**: The change in business inventories ratio 
$\overline{\left[ \frac{\mathit{cbi}}{\mathit{gdp}} \right]}^{\mathrm{ss}}$ has 
a 
**constant trend** set at the steady-state parameter level (no time variation). 
The statistical discrepancy ratio trend is **fixed at zero always**: 
$\overline{\left[ \frac{\mathit{sdx}}{\mathit{gdp}} \right]}_t = 0$.

### Bottom-up GDP Level Identity

The actual GDP identity in levels:

$$\mathit{gdp}^{\mathrm{ident}}_t = \mathit{cpr}_t + \mathit{cgg}_t + 
\mathit{fcf}_t + \mathit{xgs}_t - \mathit{mgs}_t + \left[ 
\frac{\mathit{cbi}}{\mathit{gdp}} \right]_t \times \mathit{gdp}_t + \left[ 
\frac{\mathit{sdx}}{\mathit{gdp}} \right]_t \times \mathit{gdp}_t$$

### Top-down Bottom-up Reconciliation

$$\mathit{gdp}^{\mathrm{ident}}_t = \mathit{gdp}_t \times 
\mathit{gdp}^{\mathrm{resid}}_t$$

where $\mathit{gdp}^{\mathrm{resid}}_t$ captures any discrepancies between 
top-down and 
bottom-up GDP measures.

## External Variables Trends

These equations define the long-run evolution of external variables that affect 
domestic economic conditions through trade and competitiveness channels.

### Terms of Trade Trend-Gap Identity

$$\mathit{tot}_t = \overline{\mathit{tot}}_t \times \tilde{\mathit{tot}}_t$$

### Terms of Trade Trend

Terms of trade follow a random walk with drift:

$$\log \overline{\mathit{tot}}_t = \log \overline{\mathit{tot}}_{t-1} + 
\varepsilon_{\overline{\mathit{tot}},t}$$

### Annual Moving Average Terms of Trade

$$\mathit{tot}^{\mathrm{ann}}_t = \sum_{j=0}^{3} \mathit{tot}_{t-j}$$

## Price Level and Inflation Trends

These equations establish the long-run inflation dynamics and the relationship 
between nominal and real variables in the model.

### CPI Inflation Trend

$$\begin{align*}
4 \, \Delta \log \overline{\mathit{cp\imath}}_t &= 
c_0 \, \cdot \, 4 \, \Delta \log \overline{\mathit{cp\imath}}_{t-1} \\
&\quad + (1 - c_0) \, \cdot \, 4 \, \Delta \log 
\overline{\mathit{cp\imath}}^{\mathrm{ss}} \\
&\quad + \varepsilon_{\Delta \log \overline{\mathit{cp\imath}},t}
\end{align*}$$


## Interest Rate Equations

These equations define the relationships between nominal and real interest 
rates and establish their long-run trend behavior.

### Real Interest Rate Definition

The Fisher equation linking nominal rates, real rates, and expected inflation:

$$\mathit{r\imath}_t = i_t - 4 \, \Delta \log 
\mathit{cp\imath}^{\mathrm{ste}}_{t+1}$$

### Real Interest Rate Trend-Gap Identity

$$\mathit{r\imath}_t = \overline{\mathit{r\imath}}_t + 
\tilde{\mathit{r\imath}}_t$$

### Real Interest Rate Trend

$$\begin{align*}
\overline{\mathit{r\imath}}_t &= c_0 \, \overline{\mathit{r\imath}}_{t-1} + (1 
- c_0) \, \overline{\mathit{r\imath}}^{\mathrm{ss}} \\
&\quad + \varepsilon_{\overline{\mathit{r\imath}},t}
\end{align*}$$

### Nominal Interest Rate Trend

$$\overline{i}_t = \overline{\mathit{r\imath}}_t + 4 \, \Delta \log 
\overline{\mathit{cp\imath}}_t$$

## Exchange Rate Equations

These equations define real and nominal exchange rate relationships and 
establish their trend-cycle decompositions with forward-looking elements.

### Real Exchange Rate Definition

The CPI-based real exchange rate:

$$\mathit{re}_t = \frac{\mathit{cp\imath}^{\star}_t \times 
e_t}{\mathit{cp\imath}_t}$$

where $\mathit{cp\imath}^{\star}_t$ is the foreign price level and $e_t$ is the 
nominal exchange rate.

### Real Exchange Rate Trend-Gap Identity

$$\mathit{re}_t = \overline{\mathit{re}}_t \times \tilde{\mathit{re}}_t$$

### Real Exchange Rate Trend

$$\begin{align*}
4 \, \Delta \log \overline{\mathit{re}}_t &= 
c_0 \, \cdot \, 4 \, \Delta \log \overline{\mathit{re}}_{t-1} \\
&\quad + (1 - c_0) \, \cdot \, 4 \, \Delta \log 
\overline{\mathit{re}}^{\mathrm{ss}} \\
&\quad + c_1 \, \cdot \, 4 \, \log \tilde{\mathit{re}}_{t+1} \\
&\quad + \varepsilon_{\Delta \log \overline{\mathit{re}},t}
\end{align*}$$

### Nominal Exchange Rate Trend Growth

$$\Delta \log \overline{e}_t = \Delta \log \overline{\mathit{re}}_t - \Delta 
\log \overline{\mathit{cp\imath}}^{\star}_t + \Delta \log 
\overline{\mathit{cp\imath}}_t$$

## UIP Disparity Equations

These equations model deviations from uncovered interest parity and their 
long-run equilibrium relationships.

### UIP Disparity Trend-Gap Identity

$$\mathit{d\imath sp}_t = \overline{\mathit{d\imath sp}}_t + 
\tilde{\mathit{d\imath sp}}_t$$

### UIP Trend Relationship

The long-run uncovered interest parity condition:

$$\overline{\mathit{r\imath}}_t - \overline{\mathit{r\imath}}^{\star}_t = 4 \, 
\Delta \log \overline{\mathit{re}}_{t+1} + \overline{\mathit{d\imath sp}}_t$$

**Important**: The UIP disparity trend $\overline{\mathit{d\imath sp}}_t$ is 
**not modeled 
separately**. It is determined residually from the UIP trend relationship above 
to 
ensure consistency between real interest rate trends and expected real exchange 
rate 
changes. There is no independent autoregressive process or steady-state 
parameter 
for the disparity trend - it adjusts endogenously to satisfy the long-run 
uncovered interest parity condition.

## Notation

- $\tilde{x}$ denotes gaps (proportional deviations from trend)
- $\overline{x}$ denotes trends
- $\Delta \log x$ denotes log growth rates (Q/Q)
- $\Delta^4 \log x$ denotes year-over-year log growth rates
- $\star$ denotes external variables
- $\mathrm{ste}$ denotes short-term expectations
- $\mathrm{ss}$ denotes steady-state values
- $\mathrm{ann}$ superscript denotes annual moving averages (4-quarter sums)
- $\left[ \frac{x}{y} \right]_t$ denotes ratios
- $\varepsilon_{x,t}$ denotes structural shocks to trends
- $c_0, c_1$ denote autoregressive parameters

## Mathematical Conventions

### Multiplicative Trend-Gap Decomposition

A key feature of this model is the **multiplicative trend-gap decomposition** 
applied to all variables. For any variable $x_t$:

$$x_t = \overline{x}_t \times \tilde{x}_t$$

where:
- $\overline{x}_t$ is the trend component
- $\tilde{x}_t$ is the gap component (proportional deviation from trend)
- When $\tilde{x}_t = 1$, the variable equals its trend
- When $\tilde{x}_t > 1$, the variable is above trend
- When $\tilde{x}_t < 1$, the variable is below trend

This multiplicative structure ensures that gaps represent proportional 
deviations and is particularly suitable for maintaining positivity constraints 
in economic variables.

### First Difference Operator

The symbol $\Delta$ denotes the first difference operator in its conventional 
meaning. For any variable $x_t$:

$$\Delta \log x_t = \log x_t - \log x_{t-1}$$

This represents the log rate of growth, which provides a close approximation to 
the percentage rate of change for small changes.
