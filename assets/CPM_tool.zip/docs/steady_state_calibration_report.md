# Steady-State Calibration Report

## Purpose

The steady-state calibration report provides a critical validation step to
ensure the economic model's long-term equilibrium assumptions reflect the
country expert's assessment of current economic conditions and likely
structural developments over the forecast horizon. This step should be executed
after preparing historical data and before filtering.

## Expert Judgment vs. Historical Data

**Primary Focus**: The steady-state calibration should primarily reflect the
**country expert's view** about:
- Current economic structure and conditions
- Expected structural changes over the forecast period
- Policy environment and institutional developments
- External economic relationships and trade patterns

**Historical Data as Context**: Historical trends provide useful context but
should **not be the primary driver** of steady-state assumptions, particularly
for focus countries undergoing structural transformation.

## Why Historical Data May Mislead

Focus countries (Bhutan, Philippines, India) are economies experiencing
significant structural changes where:

- **Structural transformation**: Economic composition is evolving (agriculture
  to services/manufacturing)
- **Financial deepening**: Credit markets, banking systems, and monetary
  transmission are changing
- **Trade integration**: Export/import patterns and external relationships are
  shifting
- **Policy reforms**: Fiscal, monetary, and regulatory frameworks are being
  modernized
- **Demographic transitions**: Labor force and consumption patterns are changing

Historical averages may not capture these ongoing transformations and could
lead to inappropriate forecasting assumptions.

## What the Report Shows

### Charts Generated

**GDP Component Ratios** (as percentages of GDP):
- Private consumption (CPR)
- Government consumption (CGG) 
- Fixed capital formation (FCF)
- Exports of goods & services (XGS)
- Imports of goods & services (MGS)
- Change in business inventories (CBI)
- Statistical discrepancy (SDX)

**Economic Rates**:
- Real GDP growth (annual %)
- CPI inflation (annual %)
- Nominal USD exchange rate change (annual %)
- Real USD exchange rate change (annual %)
- Nominal interest rate (%)
- Real interest rate (%)

Each chart displays:
- **Historical data**: Actual observed values
- **Weighted averages**: Smoothed historical trends
- **Steady-state values**: Model's calibrated long-term assumptions

## How to Interpret and Adjust

### Key Questions for Country Experts

1. **Do steady-state assumptions reflect current economic reality?**
   - Are GDP component shares consistent with recent structural changes?
   - Do growth assumptions align with productivity and demographic trends?

2. **Are assumptions forward-looking?**
   - Do they incorporate expected policy changes?
   - Do they reflect evolving external economic relationships?

3. **Are historical deviations explained by structural breaks?**
   - Can gaps between historical and steady-state values be attributed to
     one-off events or structural transitions?
   - Should recent trends carry more weight than distant historical averages?

### When to Prioritize Expert Judgment

- **Large historical volatility**: When historical data shows high variability
  due to external shocks or policy changes
- **Recent structural breaks**: When economic relationships have fundamentally
  changed
- **Forward-looking policy changes**: When announced reforms will alter future
  economic structure
- **External environment shifts**: When global conditions or trade relationships
  are evolving

### Adjustment Process

If steady-state assumptions need revision:

1. **Document reasoning**: Record why expert judgment differs from historical
   patterns
2. **Update model parameters**: Modify calibration values in the country's
   parameter files
3. **Re-run calibration**: Regenerate the model and steady-state report
4. **Validate consistency**: Ensure adjusted assumptions are internally
   consistent and economically plausible

## Command

```bash
python -m {country}.report_steady_calibration
```

## Key Principle

The steady-state calibration should embody the country expert's best assessment
of the economy's likely structure during the forecast period, informed by but
not constrained by historical patterns. This forward-looking approach is
essential for generating relevant and useful forecasts in rapidly evolving
economies.