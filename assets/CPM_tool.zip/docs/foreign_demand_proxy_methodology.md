# Foreign Demand Proxy Methodology for Macroeconomic Models

## Overview

This document outlines the methodology for constructing foreign demand proxies for the Philippines, India, and Bhutan. The indices are weighted averages of real GDP cycles from four major economies, with weights based on trade relationships and economic integration.

## Representative Economies

Four representative economies are selected based on economic significance, data availability, and trade relevance:

| Economy | Rationale | Data Availability |
|---------|-----------|------------------|
| **United States** | Major global economy and key trading partner | Quarterly GDP data, BEA |
| **China** | Largest trading partner for many Asian countries | Quarterly GDP data, National Bureau of Statistics |
| **Euro Area** | Represents European demand | Quarterly GDP data, ECB/Eurostat |
| **Japan** | Major Asian economy and significant trading partner | Quarterly GDP data, Cabinet Office |

These four economies provide comprehensive global coverage and reliable quarterly GDP data.

## Country-Specific Analysis and Weights

### Philippines

#### Trade Pattern Analysis

The US is the largest export partner (15.7% of exports, $11.53B in 2023-24), while China dominates imports ($29.4B in 2023). Japan ranks among the top 10 trading partners with significant bilateral trade. East Asia accounts for 50.4% of export value, reflecting strong regional integration.

#### Proposed Weights for Philippines

| Economy | Weight | Justification |
|---------|--------|---------------|
| **United States** | 35% | Largest export partner, major demand source |
| **China** | 30% | Leading import partner, regional trade dominance |
| **Euro Area** | 20% | European trade relationships |
| **Japan** | 15% | Significant Asian trading partner, regional integration |

**Total Trade Volume (2023)**: Exports $115.26B, imports $159.29B.

### India

#### Trade Pattern Analysis

China is India's largest trading partner ($118.4B in FY 2023-24), followed by the US ($71.39B). Japan is a key trading partner, particularly for technology and manufacturing goods. Trade with China grew modestly (imports +3.24%, exports +8.7%), while US trade showed mixed patterns.

#### Proposed Weights for India

| Economy | Weight | Justification |
|---------|--------|---------------|
| **United States** | 30% | Major export destination, significant bilateral trade |
| **China** | 35% | Largest trading partner, dominant import source |
| **Euro Area** | 20% | Important European trade relationships |
| **Japan** | 15% | Key technology and manufacturing partner |

**Total Trade Volume (FY 2023-24)**: Exports $776.68B, imports $854.80B.

### Bhutan

#### Trade Pattern Analysis

Bhutan's trade is heavily concentrated with India (79.91% of imports, 52.7% of exports), while China accounts for 6.46% of imports. European markets, particularly Italy and Netherlands, are key destinations for ferroalloy exports. Japan appears among other trading partners for imports.

#### Proposed Weights for Bhutan

| Economy | Weight | Justification |
|---------|--------|---------------|
| **United States** | 10% | Global demand proxy, minimal direct trade |
| **China** | 20% | Secondary trading partner, regional influence |
| **Euro Area** | 55% | Major ferroalloys export destination |
| **Japan** | 15% | Asian trading partner, regional demand proxy |

**Trade Characteristics**: Small, open economy (trade = 78% of GDP) closely integrated with India through trade and monetary arrangements.

## Summary of Proposed Weights

| Country | US | China | Euro Area | Japan | Total |
|---------|----|----|-------|-------|-------|
| **Philippines** | 35% | 30% | 20% | 15% | 100% |
| **India** | 30% | 35% | 20% | 15% | 100% |
| **Bhutan** | 10% | 20% | 55% | 15% | 100% |

## Trade Data Summary

### Key Trading Partners (2023-2024)

**Philippines**: US leads exports (15.7%), China dominates imports ($29.4B). Total trade: $274.55B.

**India**: China largest partner ($118.4B), US second ($71.39B). Total trade: $1.63T.

**Bhutan**: India dominant (79.91% imports, 52.7% exports), Euro Area key for ferroalloys. Trade = 78% of GDP.

## Methodology Notes

### Data Sources

1. **US GDP**: Bureau of Economic Analysis (quarterly)
2. **China GDP**: National Bureau of Statistics (quarterly)  
3. **Euro Area GDP**: ECB/Eurostat (quarterly)
4. **Japan GDP**: Cabinet Office (quarterly)

### Weighting Rationale

Weights reflect actual trade relationships, economic integration, and regional representation while ensuring reliable data availability.

### Model Implementation

```
FD_i,t = w_US * GDP_US,t + w_CN * GDP_CN,t + w_EA * GDP_EA,t + w_JP * GDP_JP,t
```

Where:
- `FD_i,t` = Foreign demand index for country i at time t
- `w_j` = Weight for economy j (US, China, Euro Area, Japan)
- `GDP_j,t` = Real GDP growth/cycle for economy j at time t

### Limitations

1. **Simplified representation**: Four-country weights cannot capture full trade complexity
2. **Time-varying patterns**: Weights may require periodic updates as trade evolves
3. **Supply chain effects**: Indirect trade linkages not fully captured
4. **Goods focus**: Primarily reflects goods rather than services trade

## Supporting Trade Evidence

### Philippines
- **Key Partners**: US (top export destination, 15.7%), China (top import source, $29.4B), Japan (significant bilateral partner)
- **Products**: Electronics (52.8% of exports), manufactured goods, minerals
- **Regional**: East Asia dominates trade flows (50.4% export value)

### India  
- **Key Partners**: China ($118.4B total trade), US ($71.39B), Japan (technology/manufacturing)
- **Trends**: China trade growing moderately, US trade mixed, diverse partner base

### Bhutan
- **Structure**: India-dominated (79.91% imports, 52.7% exports)
- **Key Products**: Electricity (31.9%), ferrosilicons (26%) 
- **Markets**: European destinations important for industrial exports

## References

Key sources include Philippine Statistics Authority (2023), India Briefing (2024), Lloyd's Bank Trade (2024), World Bank WITS Database (2023), and various national statistical agencies providing official trade data for 2023-2024.

---

*Document updated: February 2026*  
*Foreign demand methodology incorporating four external economies: US, China, Euro Area, and Japan*
