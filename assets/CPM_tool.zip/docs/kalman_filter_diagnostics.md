
# Model diagnostics based on the Kalman filter

---
### Why we cannot use econometric formalism

##### Unobservables and "pile-up problem"

The model logic based on unobservables (trends, gaps, etc.) is not testable with
econometric methods - "pile-up problem" with the data likelihood.

##### Forward-looking expectations

Formal estimation or validation of models with forward-looking expectations is extremely difficult because of an ever-changing information set (which is quite necessarily always crudely simplify in estimation exercises).

##### Forward-looking calibration

Calibration of the model is "forward-looking" and based on economic theory, not
primarily on fitting the data, for instance

 * the definition of potential output as a "smooth" permanent component of GDP,
   not as a "statistical" trend.

* steady-state GDP ratios are calibrated to reflect the most recent developments
  and reasonable assumptions about the future, not to fit the data.

##### Forecast production process

The forecast production itself is a complex process, not a mechanical run of a
model (which is the case e.g. when running VAR models):

* external assumptions

* judgmentally modified initial conditions (trends-gaps)

* judgmental adjustments on the forecast horizon 

---

### Simple heuristic diagnostics

##### Transition shock estimates

Plot the time series and histograms for the estimates of structural (transition)
shocks. These are not quantities defining the model-based likelihood of the
data (see information-adjusted prediction errors below) but rather unobserved
quantities that the Kalman filter infers from the data given the model's
structural relationships.

**Definition**: Transition shocks are the stochastic innovations in the model's
state equations that drive the evolution of unobserved components (trends,
gaps, etc.). The Kalman filter estimates these shocks as:

    ε_{t|T} = (estimated shock value given full sample information)
    ε_{t|t} = (estimated shock value given real-time information)

where shocks drive equations like:
- Trend growth processes: Δtrend_t = μ + ε^trend_t
- Gap persistence: gap_t = ρ·gap_{t-1} + ε^gap_t
- Measurement error: obs_t = true_t + ε^measurement_t

**Economic interpretation**: Each type of shock has specific economic meaning:

- **Trend shocks**: Permanent changes to the growth path of real variables
  (productivity innovations, structural breaks)
- **Gap shocks**: Temporary demand/supply disturbances that create cyclical
  fluctuations around trends
- **Measurement shocks**: Data irregularities, statistical revisions, or
  model-reality misalignment not captured by structural relationships
- **External shocks**: Innovations to foreign variables or commodity prices
- **Policy shocks**: Unexpected monetary or fiscal policy actions

**Calibration-induced bias in shock estimates**: A key consideration is that
these models are calibrated to capture recent developments and expected future
tendencies rather than historical averages. For example:

- Steady-state GDP ratios (consumption/GDP, investment/GDP, etc.) reflect
  current economic structure and likely future evolution
- Trend growth rates are set based on recent productivity developments and
  demographic projections

This forward-looking calibration can create systematic patterns in estimated
historical shocks:

- If actual GDP growth was systematically higher than the calibrated steady-state
  in earlier periods, trend shocks will appear persistently positive in the past
- If consumption patterns shifted structurally over the sample, measurement
  shocks to consumption equations may show directional bias
- Changes in financial market development or trade integration can generate
  apparent "shocks" that are actually gradual structural evolution

These patterns are **not necessarily problematic** - they reflect the tension
between using models for forward-looking forecasts (requiring contemporary
calibration) versus explaining historical data (requiring time-varying or
historically-averaged parameters).

**Diagnostic value**:

1. **Shock timing and magnitude**: Large shocks should coincide with known
   historical events (financial crises, policy changes, external disruptions)

2. **Systematic bias patterns**: Persistent directional bias in shocks may
   indicate:
   - Structural changes over the sample period
   - Mismatch between forward-looking calibration and historical reality
   - Missing time-variation in key relationships

3. **Shock correlation patterns**: Unrealistic correlations across shock types
   may indicate model misspecification:
   - Highly correlated trend and gap shocks suggest unclear trend-cycle
     decomposition
   - Persistent measurement shocks may indicate systematic data issues or
     missing structural relationships

4. **Cross-country shock comparison**: Similar countries should exhibit
   comparable shock patterns during common global events, accounting for
   different calibration choices

**Visualization recommendations**:

- Time series plots with key historical events and structural breaks annotated
- Distribution plots checking for systematic bias (mean significantly different
  from zero) and outliers
- Rolling averages to identify persistent directional patterns
- Cross-correlation matrices across shock types
- Cross-country comparison charts, noting different calibration assumptions

**Interpretation caveats**:

- Systematic patterns in shocks may reflect appropriate forward-looking
  calibration rather than model problems
- Large shocks during known crisis periods are expected and desirable
- Shock estimates depend on the entire model specification and calibration
  strategy
- Real-time vs. smoothed shock estimates can differ substantially

##### Information-adjusted prediction errors

Plot the time series and histograms for "information-adjusted prediction errors"
(IAPE). These metrics provide a unified way to evaluate model performance across
variables with heterogeneous data coverage (some observed, some unobserved,
different frequencies across countries).

**One-sided IAPE**: For any variable x at time t, the one-sided
information-adjusted prediction error is defined as:

    One-sided IAPE(x_t) = x_{t|t} - x_{t|t-1}

where:
- x_{t|t-1} is the model's prediction of x at time t, based on information up
  to t-1
- x_{t|t} is the Kalman filter's estimate of x at time t, incorporating all
  available observations at time t (filtering step)

**Two-sided IAPE**: Alternatively, the two-sided version uses full-sample
information:

    Two-sided IAPE(x_t) = x_{t|T} - x_{t|t-1}

where x_{t|T} is the Kalman smoother's estimate using information from the
entire sample.

**Interpretation**:

- For **observed variables**: One-sided IAPE equals the standard prediction
  error (actual observation minus prediction). Two-sided IAPE incorporates
  additional information from future observations, which can be useful for
  ex-post model evaluation.

- For **unobserved variables**: Both metrics measure indirect information
  content - how much other observed variables update our estimate of the
  unobserved variable relative to the model's pure prediction. One-sided IAPE
  uses real-time information (as available during forecast production), while
  two-sided IAPE uses hindsight to provide the best possible estimate.

**Advantages**:

1. **Unified metric**: Same interpretation across observed and unobserved
   variables
2. **Cross-country comparability**: Countries with different data coverage can
   be evaluated using the same framework
3. **Information weighting**: Variables are weighted by their information
   content rather than just their observability
4. **Structural insight**: For unobserved components (trends, gaps), large
   values indicate that the model's structural relationships are being
   "surprised" by the data
5. **Real-time vs. hindsight**: One-sided IAPE reflects real-time forecast
   challenges, while two-sided IAPE provides cleaner structural diagnostics

**Usage notes**: Large or systematic patterns in information-adjusted
prediction errors may indicate:
- Misspecified trend-cycle decomposition
- Missing structural relationships
- Inadequate shock processes
- Parameter miscalibration

Unlike standard econometric diagnostics, these should be interpreted as
heuristic indicators rather than formal statistical tests, given the
forward-looking calibration approach used in these models.
