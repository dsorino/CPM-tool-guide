# Foreign Trade Parameter Calibration Guidance

## Executive Summary

This document provides empirical guidance for calibrating three key foreign trade parameters in the ADB macroeconomic models for the Philippines, India, and Bhutan: `c3_gdp_gap` (terms of trade effect on output gap), `c4_gdp_gap` (foreign demand effect on output gap), and `c2_roc_cpi` (real exchange rate effect on inflation). Based on extensive literature review of small open economy DSGE models and empirical evidence, we recommend differentiated parameter values reflecting each country's trade openness and economic structure.

## Parameter Overview and Model Context

### Model Structure
The parameters operate within a gap-based macroeconomic framework where:

**GDP Gap Equation:**
```
log(gdp_gap) = c0_gdp_gap * log(gdp_gap[-1]) 
               - c1_gdp_gap * ri_gap 
               + c2_gdp_gap * log(rewx_gap) 
               + c3_gdp_gap * log(tot_gap) 
               + c4_gdp_gap * log(gdpwx_gap) 
               + shocks
```

**Phillips Curve:**
```
4*log(roc_cpi) = c0_roc_cpi * 4*log(roc_cpi[-1]) 
                + (1 - c0_roc_cpi) * 4*log(roc_cpi_ste) 
                + c1_roc_cpi * log(gdp_gap) 
                + c2_roc_cpi * log(rewx_gap) 
                + shocks
```

Where:
- `c3_gdp_gap`: Terms of trade gap effect on GDP gap  
- `c4_gdp_gap`: Foreign demand gap effect on GDP gap
- `c2_roc_cpi`: Real exchange rate gap effect on inflation

## Literature Evidence and Calibration Rationale

### 1. Terms of Trade Parameter (c3_gdp_gap)

**Empirical Range**: 0.05 - 0.25 for small open economies

**Literature Evidence:**
- Australian DSGE models estimate terms of trade effects on output gap ranging from 0.08-0.15, with emerging markets showing higher sensitivity
- Studies of India vs. US show emerging markets have steeper aggregate supply curves, implying stronger terms of trade transmission
- Open economy models show terms of trade externalities significantly affect optimal policy and output volatility

**Economic Rationale:**
- Terms of trade improvements boost real income and demand
- Effect stronger in commodity-dependent economies 
- More trade-open economies show higher sensitivity

### 2. Foreign Demand Parameter (c4_gdp_gap)  

**Empirical Range**: 0.10 - 0.30 for small open economies

**Literature Evidence:**
- Federal Reserve analysis finds foreign output gap coefficients often exceed domestic ones in magnitude for open economies, with statistical significance at 1% level
- Panel study of 48 countries shows global output gaps significantly affect domestic inflation across regions and time periods
- RBA small open economy model shows foreign output gaps enter IS equations with coefficients typically 0.15-0.25

**Economic Rationale:**
- Foreign demand drives export performance
- Effect amplified by trade integration and supply chain linkages
- Coefficient should reflect weighted trading partner relationships
- **Import-driven openness reduces this effect** - economies with high imports but limited export capacity show weaker foreign demand transmission

### 3. Real Exchange Rate Parameter (c2_roc_cpi)

**Empirical Range**: 0.03 - 0.15 for Phillips curve

**Literature Evidence:**
- New Keynesian Phillips curve studies find external inflation drivers often more relevant than domestic output gaps, with exchange rate pass-through coefficients 0.05-0.12
- Analysis of small open economies shows exchange rate pass-through varies significantly, with specifications incorporating import prices performing better than terms of trade measures
- Recent IMF analysis shows pass-through effects rise with economy openness but are dampened by local currency pricing

**Economic Rationale:**
- Real exchange rate depreciation increases import prices
- Effect varies with import content and pass-through rates
- Emerging markets typically show higher pass-through

## Country-Specific Calibration Recommendations

#### Philippines
**Trade Characteristics**: Medium openness (27% exports/GDP), diversified partners, strong regional integration

**Recommended Parameters:**
- `c2_roc_cpi`: **0.08** - Moderate exchange rate pass-through reflecting balanced trade structure
- `c3_gdp_gap`: **0.12** - Reflecting commodity exposure and trade openness  
- `c4_gdp_gap`: **0.18** - Strong regional trade integration and export orientation

#### India  
**Trade Characteristics**: Large economy with moderate openness (22% exports/GDP), diversified global trade

**Recommended Parameters:**
- `c2_roc_cpi`: **0.06** - Controlled exchange rate pass-through in large economy
- `c3_gdp_gap`: **0.08** - Terms of trade sensitivity for large open economy
- `c4_gdp_gap`: **0.14** - Large economy's greater domestic demand orientation

#### Bhutan
**Trade Characteristics**: Very high import-driven openness (78% of GDP), concentrated trading relationships, limited export diversification

**Recommended Parameters:**
- `c2_roc_cpi`: **0.25** - Very high pass-through due to extreme import dependence
- `c3_gdp_gap`: **0.20** - High sensitivity reflecting commodity export dependence and small economy vulnerability to price changes
- `c4_gdp_gap`: **0.08** - **Low coefficient** reflecting that high openness is import-driven rather than export-driven

**Bhutan-Specific Rationale:**
Bhutan's 78% trade/GDP ratio is primarily driven by imports (79.91% from India), while exports are highly concentrated in specific sectors (electricity 31.9%, ferrosilicons 26%). This means:
1. Foreign demand gaps have limited transmission to domestic GDP
2. Terms of trade effects are more important due to commodity export concentration  
3. Exchange rate pass-through remains very high due to import dependence

## Robustness Considerations

### Parameter Interactions
- Higher `c4_gdp_gap` may require slightly lower `c2_gdp_gap` (real exchange rate effect) to maintain stability
- Countries with higher trade weights should have correspondingly higher foreign coefficients, **except when openness is primarily import-driven**
- Parameters should be tested for model stability and reasonable impulse responses

### Empirical Validation
- **Phillips Curve Slope**: Recent studies suggest Phillips curve flattening in post-crisis period, supporting moderate parameter values
- **Foreign Spillovers**: Evidence shows declining domestic gap effects but stable global gap effects post-2008 in advanced economies
- **Exchange Rate Pass-through**: Pass-through strength varies significantly with indexation mechanisms and price stickiness

### Model Validation Tests
1. **Impulse Response Functions**: Foreign demand shocks should generate positive GDP responses proportional to export orientation
2. **Variance Decomposition**: Foreign factors should explain 15-40% of GDP gap variance in export-oriented small open economies, less in import-dependent ones  
3. **Historical Episodes**: Parameters should replicate reasonable responses to major external shocks
4. **Cross-correlations**: Foreign variables should lead domestic variables by 1-2 quarters in export-oriented economies

## Implementation Summary

The recommended calibration reflects each country's trade characteristics and transmission mechanisms:
- **Philippines**: Moderate parameters reflecting balanced regional integration and export competitiveness
- **India**: Conservative parameters recognizing large economy dynamics with growing trade integration
- **Bhutan**: Mixed calibration - high terms of trade and exchange rate sensitivity due to commodity dependence and import reliance, but **low foreign demand sensitivity** due to import-driven openness and limited export diversification

**Key Insight**: High trade openness does not automatically imply high foreign demand sensitivity when that openness is primarily import-driven. Economies like Bhutan are more sensitive to terms of trade (affecting export revenues) and exchange rates (affecting import costs) than to broad foreign demand cycles.

## References

Key sources include small open economy DSGE literature from RBA (Australia), Federal Reserve (US), ECB (Euro Area), and IMF studies on emerging market economies. The calibration draws on empirical estimates from Galí and Monacelli (2005), recent Federal Reserve analysis of global slack effects, and emerging market studies from India and other small open economies.