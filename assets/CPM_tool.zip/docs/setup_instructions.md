# Setup Instructions

This document provides step-by-step instructions for setting up the ADB
macroeconomic forecasting system on your local machine.

## Prerequisites

#### System Requirements

- Python 3.12 or higher
- Git command-line tools

#### GitHub Account and Access

1. Create a GitHub account if you don't have one

2. Request access to the `ADB-Modeling` organization

2. Create a personal access token (PAT) with appropriate scopes for repository
   access covering all required repositories.

3. Verify you can access the following repository:
   `https://github.com/ADB-Modeling/modeling_infrastructure`

## Repository Setup

#### Create Project Directory

Create a main project directory to contain all ADB repositories, e.g.
`adb_models`:

```bash
mkdir adb_models
cd adb_models
```

#### Clone ADB Model Repositories

Clone the following repositories from the ADB-Modeling organization, ensuring
they are at the same directory level:

```bash
git clone https://{PAT}@github.com/ADB-Modeling/datastore.git
git clone https://{PAT}@github.com/ADB-Modeling/datastore_api.git
git clone https://{PAT}@github.com/ADB-Modeling/datastore_pumps.git

git clone https://{PAT}@github.com/ADB-Modeling/model_infrastructure.git
git clone https://{PAT}@github.com/ADB-Modeling/reporting_infrastructure.git
git clone https://{PAT}@github.com/ADB-Modeling/docs.git

git clone https://{PAT}@github.com/ADB-Modeling/us.git
git clone https://{PAT}@github.com/ADB-Modeling/ea.git
git clone https://{PAT}@github.com/ADB-Modeling/jp.git
git clone https://{PAT}@github.com/ADB-Modeling/cn.git

git clone https://{PAT}@github.com/ADB-Modeling/bt.git
git clone https://{PAT}@github.com/ADB-Modeling/in.git
git clone https://{PAT}@github.com/ADB-Modeling/ph.git
```

where you replace `{PAT}` with your personal access token.

#### Verify Directory Structure

Your project directory should contain all the repository folders:

```
adb_models/
├── bt
├── cn
├── datastore
├── datastore_api
├── datastore_pumps
├── docs
├── ea
├── in
├── jp
├── model_infrastructure
├── ph
├── reporting_infrastructure
└── us
```

## Python Environment Setup

#### Create Virtual Environment

Use a virtual environment to manage dependencies. In the main project directory,
run

```bash
python -m venv adb_venv
```

#### Activate Virtual Environment

- On Windows:
    ```bash
    adb_venv\Scripts\activate
    ```

- On macOS/Linux:
    ```bash
    source adb_venv/bin/activate
    ```

#### Install Required Packages

Install necessary Python packages as specified in the `requirements.txt` file
located in this `docs` repository:

```bash
pip install -r docs/requirements.txt
```

## Running the System

#### Working Directory

Always execute Python commands from the main project directory 
(`adb_models/`), not from individual repository folders.

#### Command Execution

Use Python module execution syntax:

```bash
python -m datastore_pumps.update_all
python -m us.create_model
python -m ph.create_model
```

On Windows, you may also use:

```bash
py -m datastore_pumps.update_all
py -m us.create_model
py -m ph.create_model
```

If using IPython, use the `run` magic command:

```python
run -m datastore_pumps.update_all
run -m us.create_model
run -m ph.create_model
```

### Example Workflow Commands

From the main `adb_models/` directory:

1. Update data:
   ```bash
   python -m datastore_pumps.update_all
   ```

2. Create external environment models:
   ```bash
   python -m us.create_model
   python -m cn.create_model
   ```

3. Create focus country models:
   ```bash
   python -m ph.create_model
   python -m in.create_model
   python -m bt.create_model
   ```

