# Steady State Calibration Logic

This document describes the **top-down hierarchical approach** to calibrating 
the steady state parameters of the ADB macroeconomic model. The calibration 
follows a systematic sequence that ensures internal consistency across all 
variables and identities, starting from fundamental growth assumptions and 
cascading down to derived equilibrium values.

## Overview of the Top-Down Approach

The steady state calibration is structured as a **hierarchical cascade** where 
higher-level parameters determine lower-level ones through economic identities 
and equilibrium conditions. This top-down approach ensures that:

1. **No circular dependencies** exist between parameters
2. **All identities hold exactly** in steady state
3. **Economic consistency** is maintained across all variables
4. **Policy-relevant parameters** (like growth targets) drive the entire 
calibration

The hierarchy flows from fundamental growth rates → expenditure structure → 
supporting rates → derived equilibrium values.

## Level 1: Fundamental Growth Rates (The Foundation)

The calibration begins with the **most fundamental parameters** that define the 
long-term growth trajectory of the economy. These are **quarterly growth 
rates** expressed as natural log rates:

### Primary Growth Drivers
- **Domestic real GDP growth**: `ss_roc_gdp`
  - The steady-state quarterly growth rate $4 \, \Delta \log 
\overline{\mathit{gdp}}^{\mathrm{ss}}$ is controlled by this calibration 
parameter
  - This is the **cornerstone parameter** that determines the overall pace of 
economic expansion

- **Real exchange rate growth**: `ss_roc_re`
  - The steady-state quarterly growth rate $4 \, \Delta \log 
\overline{\mathit{re}}^{\mathrm{ss}}$ is controlled by this calibration 
parameter
  - Captures long-run competitiveness trends (appreciation/depreciation)

**Top-Down Logic**: These growth rates are typically set based on **long-term 
economic forecasts, demographic projections, and productivity assumptions**. 
They represent the fundamental drivers that all other steady state values must 
be consistent with.

## Level 2: Expenditure Structure (GDP Component Ratios)

Once GDP growth is established, the **expenditure structure** is calibrated 
through steady-state ratios. These parameters are **levels** (not growth rates) 
representing the long-run shares of each component in GDP:

### Directly Calibrated Ratios
- **Private consumption ratio**: `ss_cpr_to_gdp`
  - The steady-state ratio $\overline{\left[ \frac{\mathit{cpr}}{\mathit{gdp}} 
\right]}^{\mathrm{ss}}$ is directly set by this parameter

- **Government consumption ratio**: `ss_cgg_to_gdp`
  - The steady-state ratio $\overline{\left[ \frac{\mathit{cgg}}{\mathit{gdp}} 
\right]}^{\mathrm{ss}}$ is directly set by this parameter

- **Fixed capital formation ratio**: `ss_fcf_to_gdp`
  - The steady-state ratio $\overline{\left[ \frac{\mathit{fcf}}{\mathit{gdp}} 
\right]}^{\mathrm{ss}}$ is directly set by this parameter

- **Export ratio**: `ss_xgs_to_gdp`
  - The steady-state ratio $\overline{\left[ \frac{\mathit{xgs}}{\mathit{gdp}} 
\right]}^{\mathrm{ss}}$ is directly set by this parameter

- **Business inventories ratio**: `ss_cbi_to_gdp`
  - The steady-state ratio $\overline{\left[ \frac{\mathit{cbi}}{\mathit{gdp}} 
\right]}^{\mathrm{ss}}$ is directly set by this parameter (constant over time)

### Implications of Constant Ratios

Since these ratios are **constant** in steady state, each component 
automatically grows at exactly the same rate as GDP:

$$\overline{\mathit{cpr}}_t = \overline{\left[ 
\frac{\mathit{cpr}}{\mathit{gdp}} \right]}^{\mathrm{ss}} \times 
\overline{\mathit{gdp}}_t$$

Therefore: $4 \, \Delta \log \overline{\mathit{cpr}}_t = 4 \, \Delta \log 
\overline{\mathit{gdp}}_t$ in steady state.

**Top-Down Logic**: These ratios are typically based on **historical averages, 
structural economic analysis, and policy objectives** for the desired 
composition of economic activity.

### Residually Determined: Import Ratio

The import-to-GDP ratio is **not calibrated directly**. Instead, it is 
determined **residually** from the GDP accounting identity to ensure that all 
ratios sum to unity:

The import-to-GDP steady-state ratio $\overline{\left[ 
\frac{\mathit{mgs}}{\mathit{gdp}} \right]}^{\mathrm{ss}}$ is determined 
residually such that all expenditure ratios sum to unity.

**Top-Down Logic**: This ensures **accounting consistency** without requiring a 
separate import parameter. The import share adjusts endogenously to satisfy the 
national accounts identity: $C + G + I + X - M + \Delta \text{Inventories} = 
\text{GDP}$.

## Level 3: Supporting Variables (Rates and Prices)

The next tier involves calibrating the **supporting macroeconomic variables** 
that determine financing conditions, price dynamics, and external 
competitiveness. These are **level parameters** (not growth rates):

### Domestic Supporting Variables
- **Real interest rate**: `ss_ri`
  - The steady-state real interest rate level 
$\overline{\mathit{r\imath}}^{\mathrm{ss}}$ is directly set by this parameter 
(annual percentage points)
  - Represents the long-run equilibrium real cost of capital

- **CPI inflation rate**: `ss_roc_cpi` 
  - The steady-state quarterly inflation rate $4 \, \Delta \log 
\overline{\mathit{cp\imath}}^{\mathrm{ss}}$ is controlled by this calibration 
parameter
  - Defines the inflation target and price level trend

### External Supporting Variables
- **External real interest rate**: `ss_riw`
  - The steady-state external real interest rate level 
$\overline{\mathit{r\imath}}^{\star \mathrm{ss}}$ is directly set by this 
parameter (annual percentage points)
  - Real interest rate in the reference economy (US)

- **External CPI inflation rate**: `ss_roc_cpiw`
  - The steady-state external quarterly inflation rate $4 \, \Delta \log 
\overline{\mathit{cp\imath}}^{\star \mathrm{ss}}$ is controlled by this 
calibration parameter
  - Inflation rate in the reference economy

**Top-Down Logic**: These parameters are typically set based on **central bank 
targets, historical averages of financial market conditions, and external 
economic projections**. They provide the foundation for all financial and price 
relationships in the model.

## Level 4: Derived Equilibrium Values (Identity-Based)

The final tier consists of variables that are **automatically determined** 
through economic identities and equilibrium conditions. These parameters are 
**not calibrated directly** but emerge from the higher-level calibration 
through economic theory.

### Fisher Identity: Nominal Interest Rates

The **Fisher equation** automatically determines steady-state nominal interest 
rate trends from real rates and expected inflation:

**Domestic nominal interest rate trend:**
$$\overline{i}^{\mathrm{ss}} = \overline{\mathit{r\imath}}^{\mathrm{ss}} + 4 \, 
\Delta \log \overline{\mathit{cp\imath}}^{\mathrm{ss}}$$

**External nominal interest rate trend:**
$$\overline{i}^{\star \mathrm{ss}} = \overline{\mathit{r\imath}}^{\star 
\mathrm{ss}} + 4 \, \Delta \log \overline{\mathit{cp\imath}}^{\star 
\mathrm{ss}}$$

### UIP Identity: Disparity Trend

The **UIP disparity trend** is determined residually from the long-run 
uncovered interest parity condition:

$$\overline{\mathit{d\imath sp}}^{\mathrm{ss}} = 
\overline{\mathit{r\imath}}^{\mathrm{ss}} - \overline{\mathit{r\imath}}^{\star 
\mathrm{ss}} - 4 \, \Delta \log \overline{\mathit{re}}^{\mathrm{ss}}$$

This ensures that the **steady-state real interest rate differential** exactly 
compensates for expected real exchange rate changes plus a constant risk 
premium.

### Price Level Identity: Nominal Exchange Rate Growth

The steady-state **nominal exchange rate growth** follows from real exchange 
rate dynamics and inflation differentials:

$$4 \, \Delta \log \overline{e}^{\mathrm{ss}} = 4 \, \Delta \log 
\overline{\mathit{re}}^{\mathrm{ss}} - 4 \, \Delta \log 
\overline{\mathit{cp\imath}}^{\star \mathrm{ss}} + 4 \, \Delta \log 
\overline{\mathit{cp\imath}}^{\mathrm{ss}}$$

**Top-Down Logic**: These derived values **cannot be set independently** - they 
must satisfy the economic identities. This ensures that the steady state is 
internally consistent and represents a true economic equilibrium.

## Calibration Principles and Best Practices

### 1. **Strict Hierarchical Ordering**
- Level 1 parameters are set first based on long-term economic fundamentals
- Level 2 parameters are set next based on structural economic relationships
- Level 3 parameters are set based on monetary and external conditions
- Level 4 parameters are automatically determined and cannot be overridden

### 2. **No Circular Dependencies**
- Higher-level parameters never depend on lower-level ones
- Each level provides the foundation for the next level
- Changes propagate downward through the hierarchy, never upward

### 3. **Identity Enforcement**
- All accounting identities must hold exactly in steady state
- Fisher equations, UIP conditions, and national accounts must balance
- Any violation indicates an inconsistent calibration

### 4. **Economic Interpretability**
- Each parameter has a clear economic interpretation
- Relationships between parameters follow established economic theory
- Parameter values should be plausible given historical data and economic 
conditions

### 5. **External Anchoring**
- External economy parameters provide reference points
- Domestic parameters are calibrated relative to external benchmarks
- This ensures model consistency with global economic conditions

### 6. **Policy Relevance**
- Top-level parameters (growth rates, inflation targets) align with policy 
objectives
- The hierarchy ensures that policy goals propagate consistently throughout the 
model
- Lower-level parameters support rather than contradict policy intentions

## Implementation Sequence

When calibrating the model, follow this **strict sequence**:

1. **Set fundamental growth rates** (`ss_roc_gdp`, `ss_roc_re`)
2. **Set expenditure ratios** (`ss_cpr_to_gdp`, `ss_cgg_to_gdp`, etc.)
3. **Verify ratio consistency** (import ratio is automatically determined)
4. **Set supporting rates** (`ss_ri`, `ss_roc_cpi`, `ss_riw`, `ss_roc_cpiw`)
5. **Check derived values** (nominal rates and UIP disparity are automatically 
calculated)
6. **Validate economic consistency** across all identities and equilibrium 
conditions

This top-down approach ensures that the steady state represents a **coherent 
economic equilibrium** where all variables are mutually consistent and 
economically interpretable.