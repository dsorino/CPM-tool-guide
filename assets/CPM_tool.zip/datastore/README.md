# Datastore

This repository stores the central economic data used across all country
models. It maintains both historical time series and forecast data for
macroeconomic indicators in a structured, version-controlled format that can
be accessed by all forecasting workflows.

