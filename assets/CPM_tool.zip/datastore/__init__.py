r"""
"""

import os

THIS_PATH = os.path.dirname(os.path.abspath(__file__))
DATA_FILE_PATH = os.path.join(THIS_PATH, "data.csv", )

