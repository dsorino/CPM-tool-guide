
# External Model for Japan

This repository contains the external environment model for Japan,
representing one of the key external economies in the forecasting system. It
provides projections for Japan's GDP, inflation, interest rate, and exchange
rate that influence the domestic economies being modeled.

