
import os
import irispie as ir


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILES_DIR = os.path.join(THIS_DIR, "data_files")
PREPROCESSED_DATA_FILE = os.path.join(DATA_FILES_DIR, "preprocessed_data.csv")


