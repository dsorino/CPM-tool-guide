r"""
Creating and calibrating country model
"""


#[

# Standard library imports
import sys
import os
import json
from pprint import pp as pprint

# Third-party imports
import irispie as ir

# Application imports
import reporting_infrastructure as ri
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


#%% Calibrating country parameters
logger.info("Calibrating country parameters", )

country_parameters = dict(
    # Steady parameters
    ss_roc_gdp=1.05**(1/4),
    ss_roc_cpi=1.03**(1/4),
    ss_ri=0.5/100,
    ss_roc_re=1.015**(1/4),

    ss_cpr_to_gdp=0.73,
    ss_cgg_to_gdp=0.145,
    ss_fcf_to_gdp=0.24,
    ss_xgs_to_gdp=0.27,

    # Dynamic parameters
    c0_ri_tnd=0.98,
    c0_roc_re_tnd=0.98,

    c0_cpr_to_gdp_tnd=0.98,
    c0_cgg_to_gdp_tnd=0.98,
    c0_fcf_to_gdp_tnd=0.98,
    c0_xgs_to_gdp_tnd=0.98,
    c0_mgs_to_gdp_tnd=0.98,

    c0_cpr_gap=0.7,
    c0_cgg_gap=0.6,
    c0_fcf_gap=0.5,
    c0_xgs_gap=0.5,
    c0_mgs_gap=0.6,

    c0_tot_gap=0.5,
    c0_gdpx_gap=0.75,
    c0_rex_gap=0.75,

    c0_roc_cpi=0.7,
    c1_roc_cpi=0.1,
    c2_roc_cpi=0.05,
    cx_roc_cpi=0.5,

    c1_roc_cpi_ste=0.50,
    c0_roc_cpi_tnd=0.98,

    c0_i=0.85,

    c1_mpr=3,
    c2_mpr=0.2,
    c3_mpr=0,

    c0_disp_gap=0.5,
    c1_e_ste=0.7,

    c0_gdp_gap=0.7,
    c1_gdp_gap=0.1,
    c2_gdp_gap=0.1,
    c3_gdp_gap=0.1,
    c4_gdp_gap=0.15,
    tw_us=0.35,
    tw_cn=0.30,
    tw_jp=0.15,
    tw_ea=0.20,

    c0_roc_gdp_tnd=0.98,

    c1_cpr_gap=0,
    c2_cpr_gap=0,
    c3_cpr_gap=0,
    c1_cgg_gap=0,
    c2_cgg_gap=0,
    c3_cgg_gap=0,
    c1_fcf_gap=0,
    c2_fcf_gap=0,
    c3_fcf_gap=0,
    c1_xgs_gap=0,
    c2_xgs_gap=0,
    c3_xgs_gap=0,
    c1_mgs_gap=0, c2_mgs_gap=0,
    c3_mgs_gap=0,

    c0_cbi_to_gdp=0.4,
    c0_sdx_to_gdp=0.4,

    # Std deviations of shocks
    std_shk_roc_gdp_tnd=0.1,
    std_shk_gdp_tnd=0.0,
    std_shk_cpr_to_gdp_tnd=1,
    std_shk_cgg_to_gdp_tnd=6,
    std_shk_fcf_to_gdp_tnd=6,
    std_shk_xgs_to_gdp_tnd=6,
    std_shk_mgs_to_gdp_tnd=6,

    std_shk_tot_tnd=1,
    std_shk_ri_tnd=0.2,
    std_shk_roc_re_tnd=0.3,

    std_shk_gdp_gap=1,
    std_shk_cpr_gap=10,
    std_shk_cgg_gap=10,
    std_shk_fcf_gap=10,
    std_shk_xgs_gap=10,
    std_shk_mgs_gap=10,
    std_shk_cbi_to_gdp=1,
    std_shk_sdx_to_gdp=1,
    std_shk_tot_gap=4,
    std_shk_gdpx_gap=1,
    std_shk_rex_gap=1,

    std_shk_roc_cpi=2,
    std_shk_roc_cpi_short=0.5,
    std_shk_roc_cpi_tnd=0.1,

    std_shk_i=1,
    std_shk_e=5,
    std_shk_disp_gap=3,
)


external_parameters = dict(
    # Steady parameters
    ss_roc_gdpw=1.025**(1/4),
    ss_roc_cpiw=1.02**(1/4),
    ss_riw=0.0/100,

    # Dynamic parameters
    c0_roc_gdpw_tnd=0.98,
    c0_roc_cpiw_tnd=0.98,
    c0_riw_tnd=0.98,

    c0_gdpw_gap=0.7,
    c0_roc_cpiw=0.7,
    cx_roc_cpiw=0.5,
    c0_iw=0.85,

    c1_roc_cpiw_ste=0.50,

    # Std deviations of shocks
    std_shk_gdpw_gap=1,
    std_shk_roc_gdpw_tnd=0.1,
    std_shk_gdpw_tnd=0.0,

    std_shk_roc_cpiw=2,
    std_shk_roc_cpiw_short=0.5,
    std_shk_roc_cpiw_tnd=0.1,

    std_shk_iw=1,
    std_shk_riw_tnd=0.2,
)

parameters = country_parameters | external_parameters
pprint(parameters, )


#%% Writing parameters to JSON file
logger.info(f"Writing parameters to JSON file: {fs.PARAMETERS_FILE}, ")

with open(fs.PARAMETERS_FILE, "wt", ) as f:
    json.dump(parameters, f, indent=4, )


#%% Creating and saving model
logger.info(f"Creating and saving model to pickle file: {fs.MODEL_PICKLE_FILE}, ")

model = mi.create_model(
    parameters=parameters,
    preparsed_model_file=fs.PREPARSED_MODEL_FILE,
)

model.to_pickle_file(fs.MODEL_PICKLE_FILE, )


#%% Reporting steady table
logger.info("Reporting steady table", )

steady_table = ri.create_steady_table(
    model=model,
    round_to=6,
    write_to_csv_file=fs.STEADY_TABLE_FILE,
)

print(steady_table)


logger.info("Done creating model")

