
COUNTRY_CODE = "PH"
COUNTRY_NAME = "The Philippines"

