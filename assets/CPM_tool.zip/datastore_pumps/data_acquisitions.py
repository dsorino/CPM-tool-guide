r"""
"""


#[

from __future__ import annotations

# Typing imports
from typing import Callable

# Third-party imports
import datapie as ap
import timescroll as ts

# Application imports
import datastore_api as api
from datastore_api import MetaData

# Local imports
from .data_sources import SourceInfo, SourceInfoPattern, data_source_map, select_from_data_source_map

#]


def acquire_data_from_fred(
    data_source_map: dict[MetaData, SourceInfo],
) -> ap.Databox:
    r"""
    """
    pass


def acquire_data_from_imf(
    data_source_map: dict[MetaData, SourceInfo],
) -> ap.Databox:
    r"""
    """
    pass


def acquire_data_from_provider(
    provider: str,
    data_acquisition_method: Callable,
) -> tuple[ap.Databox, dict[str, str]]:
    r"""
    """
    relevant_map = select_from_data_source_map(
        data_source_map,
        source_info_pattern=SourceInfoPattern(provider="FRED", ),
    )
    #
    output_mapping = {}
    request_strings = []
    for metadata, source_info in relevant_map.items():
        request_strings.append(source_info.request)
        output_mapping[source_info.request] = api.storage_key_from_metadata(metadata, )

    request_strings = tuple((i.request for i in relevant_map.values()))
    db = data_acquisition_method(request_strings=request_strings, )
    missing = db.get_missing_names(request_strings, )
    if missing:
        raise ValueError(f"Missing variables when reading from FRED: {missing}")

    return db, output_mapping,

