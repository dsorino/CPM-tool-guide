r"""
"""


#[

from __future__ import annotations

# Standard library imports
import os
import csv
from collections import namedtuple

# Typing imports
from collections.abc import Iterable

# Third-party imports
import timescroll as ts

# Local imports
import datastore_api as api

#]


SOURCE_FIELDS = ("provider", "request", )
SourceInfo = namedtuple("Source", SOURCE_FIELDS, )
SourceInfoPattern = namedtuple("Source", SOURCE_FIELDS, defaults=(None, )*len(SOURCE_FIELDS), )

THIS_DIR = os.path.dirname(os.path.abspath(__file__, ), )
DATA_SOURCE_INFO_PATH = os.path.join(THIS_DIR, "data_source_info.csv", )


def read_data_source_map(
    file_name: str,
) -> dict[str, str]:
    r"""
    """
    data_source_map = {}
    with open(file_name, "r", encoding="utf-8-sig", ) as file:
        reader = csv.DictReader(file, )
        for row in reader:
            if row["origin"].strip() == "" or row["origin"].strip().startswith("#"):
                continue
            metadata = _metadata_from_row(row, )
            source_info = _source_info_from_row(row, )
            data_source_map[metadata] = source_info
    return data_source_map


def _metadata_from_row(row: dict[str, str], ) -> str:
    r"""
    """
    return api.MetaData(*(row[i] for i in api.MetaData._fields))


def _source_info_from_row(row: dict[str, str], ) -> SourceInfo:
    r"""
    """
    return SourceInfo(*(row[i] for i in SourceInfo._fields))


data_source_map = read_data_source_map(DATA_SOURCE_INFO_PATH, )
inverse_data_source_map = {
    source_info: metadata
    for metadata, source_info in data_source_map.items()
}


def select_from_data_source_map(
    data_source_map: dict,
    source_info_pattern: SourceInfoPattern | None = None,
) -> dict:
    r"""
    """
    return {
        metadata: source_info
        for metadata, source_info in data_source_map.items()
        if _match_namedtuple_pattern(source_info, source_info_pattern, )
    }


def _match_namedtuple_pattern(
    item: namedtuple,
    pattern: namedtuple,
) -> bool:
    r"""
    """
    for field in pattern._fields:
        pattern_value = getattr(pattern, field, None)
        if pattern_value is not None:
            item_value = getattr(item, field, None)
            if item_value != pattern_value:
                return False
    return True

