# Datastore Pumps

This repository contains automated data acquisition tools that collect
economic data from external sources like FRED and IMF databases. It processes
and transforms this data into the standard format used by the forecasting
system, then updates the central datastore.