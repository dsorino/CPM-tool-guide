r"""
"""

#[

from __future__ import annotations

# Standard library imports
import os

# Third-party imports
import datapie as dp
import timescroll as ts
import macrotap as mt

# Local imports
import datastore_api as api
from .data_sources import SourceInfoPattern, data_source_map, select_from_data_source_map, inverse_data_source_map
from .data_acquisitions import acquire_data_from_fred, acquire_data_from_imf

#]

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
MANUAL_UPLOAD_DIR = os.path.join(THIS_DIR, "manual", )

START_YEAR = 2000

db = dp.Databox()
output_mapping = {}


print("Acquiring FRED data...")

relevant_map = select_from_data_source_map(
    data_source_map,
    source_info_pattern=SourceInfoPattern(provider="FRED", ),
)

request_strings = []
this_output_mapping = {}
for metadata, source_info in relevant_map.items():
    request_strings.append(source_info.request)
    this_output_mapping[source_info.request] = api.storage_key_from_metadata(metadata, )

request_strings = tuple((i.request for i in relevant_map.values()))
this_db = mt.from_fred(
    request_strings=request_strings,
    target_db=db,
)
missing = this_db.get_missing_names(request_strings, )
if missing:
    raise ValueError(f"Missing variables when reading from FRED: {missing}")

db.update(this_db, )
output_mapping.update(this_output_mapping, )


#%% IMF resources

imf_resources = (
    "ANEA",
    "MFS_IR",
    "CPI",
    "ER",
    "QNEA",
)

for r in imf_resources:

    provider = f"IMF:{r}"
    print(f"Acquiring {provider} data...")

    relevant_map = select_from_data_source_map(
        data_source_map,
        source_info_pattern=SourceInfoPattern(provider=provider, ),
    )

    request_strings = []
    this_output_mapping = {}
    for metadata, source_info in relevant_map.items():
        request_strings.append(source_info.request)
        this_output_mapping[source_info.request] = api.storage_key_from_metadata(metadata, )

    this_db, info, = mt.from_imf(
        resource=f"{r}",
        request_strings=request_strings,
        target_db=db,
        group_requests_by=lambda x: x[-1],
        return_info=True,
    )
    missing = this_db.get_missing_names(request_strings, )
    if missing:
        raise ValueError(f"Missing variables when reading from {provider}: {missing}")

    db.update(this_db, )
    output_mapping.update(this_output_mapping, )


#%% ECB resources

ecb_resources = (
    "EXR",
    "ICP",
    "MNA",
    "FM",
)

for r in ecb_resources:

    provider = f"ECB:{r}"
    print(f"Acquiring {provider} data...")

    relevant_map = select_from_data_source_map(
        data_source_map,
        source_info_pattern=SourceInfoPattern(provider=provider, ),
    )

    request_strings = []
    this_output_mapping = {}
    for metadata, source_info in relevant_map.items():
        request_strings.append(source_info.request)
        this_output_mapping[source_info.request] = api.storage_key_from_metadata(metadata, )

    this_db, info, = mt.from_ecb(
        dataflow=f"{r}",
        request_strings=request_strings,
        target_db=db,
        group_requests_by=None,
        return_info=True,
    )
    missing = this_db.get_missing_names(request_strings, )
    if missing:
        raise ValueError(f"Missing variables when reading from {provider}: {missing}")

    db.update(this_db, )
    output_mapping.update(this_output_mapping, )




#%% Manual resources

manual_resources = (
    "bhutan.csv",
)

for r in manual_resources:
    provider = f"MANUAL:{r}"
    print(f"Acquiring {provider} data...")

    source_info_pattern = SourceInfoPattern(provider=provider, )

    relevant_map = select_from_data_source_map(
        data_source_map,
        source_info_pattern=SourceInfoPattern(provider=provider, ),
    )
    request_strings = []
    this_output_mapping = {}
    for metadata, source_info, in relevant_map.items():
        request_strings.append(source_info.request)
        this_output_mapping[source_info.request] = api.storage_key_from_metadata(metadata, )

    this_db = dp.Databox.from_csv_file(os.path.join(MANUAL_UPLOAD_DIR, r, ), )
    this_db.keep(request_strings, )

    missing = this_db.get_missing_names(request_strings, )
    if missing:
        raise ValueError(f"Missing variables when reading from {provider}: {missing}")

    db.update(this_db, )
    output_mapping.update(this_output_mapping, )



print("Clipping date ranges...")

db.clip(dp.mm(START_YEAR, 1), None, )
db.clip(dp.qq(START_YEAR, 1), None, )
db.clip(dp.yy(START_YEAR), None, )



print("Writing data to datastore...")

# api.apply_mapping(submission_db=db, mapping=output_mapping, )
api.submit(source_db=db, mapping=output_mapping, )

inverse_output_mapping = {
    v: k
    for k, v in output_mapping.items()
}

print("Summary of data spans:")
for name, key in output_mapping.items():
    span = db[name].span
    print(f"{key:>20}: {span.start} to {span.end}")

print("Summary of missing observations:")
for name in db.keys():
    if not db[name].has_missing:
        continue
    key = output_mapping[name]
    where = db[name].where_missing()
    print(f"{key:>20}: {" ".join(str(i) for i in where)}")

