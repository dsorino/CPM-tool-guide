# Reporting Infrastructure

This repository provides tools for creating reports, charts, and visualizations
of forecasting results. It includes functions for generating standard chart
packs, steady-state tables, and other analytical outputs used to present and
analyze the economic forecasts.