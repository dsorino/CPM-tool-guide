
#[

# Standard Library Imports
import sys

# Third-party imports
from loguru import logger

#]


__all__ = (
    "logger",
)


logger.remove()
logger.add(
   sys.stderr,
   level="INFO",
   format="<level>{time:YYYY-MM-DD HH:mm:ss.SS}|{level}|{message}</level>",
)
logger.level("INFO", color="<green>", )


