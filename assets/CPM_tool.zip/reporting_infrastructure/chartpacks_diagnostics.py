r"""
"""


#[

# Third-party imports
import datapie as dp
import irispie as ir

# Application imports
from model_infrastructure import model

#]


__all__ = (
    "chartpack_transition_shocks",
    "chartpack_iape",
    "chartpack_generalized_perrs",
    "chartpack_trend_estimates",
)


#%% Two-sided transition shocks

shock_names = model.get_names(kind=ir.TRANSITION_SHOCK, )

def is_trend_shock(name):
    return all((
        name.endswith("_tnd"),
        "w" not in name,
    ))

def is_nontrend_shock(name):
    return all((
        not name.endswith("_tnd"),
        "w" not in name,
        "tune" not in name,
        "ident" not in name,
        "ann" not in name,
    ))

trend_shock_names = [
    i for i in shock_names
    if is_trend_shock(i)
]

nontrend_shock_names = [
    i for i in shock_names
    if is_nontrend_shock(i)
]

trend_shock_names.remove("shk_gdp_tnd", )
trend_shock_names.remove("shk_mgs_to_gdp_tnd", )

ch = dp.Chartpack(
    tiles=(4, 4),
)

f = ch.add_figure(
    "{country}: Two-sided transition shocks - trends",
    show_legend=False,
)
f.add_charts([
    f"{n}: 100*smooth_{n}"
    for n in trend_shock_names
])

f = ch.add_figure(
    "{country}: Two-sided transition shocks - trends",
    show_legend=False,
    chart_type="histogram",
    vline=0,
)
f.add_charts([
    f"{n}: 100*smooth_{n}"
    for n in trend_shock_names
])

f = ch.add_figure(
    "{country}: Two-sided transition shocks - non-trends",
    show_legend=False,
)
f.add_charts([
    f"{n}: 100*smooth_{n}"
    for n in nontrend_shock_names
])


f = ch.add_figure(
    "{country}: Two-sided transition shocks - non-trends",
    chart_type="histogram",
    vline=0,
)
f.add_charts([
    f"{n}: 100*smooth_{n}"
    for n in nontrend_shock_names
])

chartpack_transition_shocks = ch



#%% One-sided information-adjusted prediction error

gperr_names = [
    "log_gdp",
    "log_cpr",
    "log_fcf",
    "log_cgg",
    "log_xgs",
    "log_mgs",

    "roc_cpi",
    "i",
    "log_e",
    "log_tot",
]


ch = dp.Chartpack(
    tiles=(4, 4),
    round_to=8,
)

for n, m, in {
    "one-sided": "update",
    "two-sided": "smooth",
}.items():

    f = ch.add_figure(
        "{country}: " + f"Information-adjusted {n} prediction errors",
        show_legend=True,
        legend=("predict", m, ),
    )
    f.add_charts([
        f"{n}: 100*(predict_{n} | {m}_{n})"
        for n in gperr_names
    ])

    f = ch.add_figure(
        "{country}: " + f"Information-adjusted {n} prediction errors",
        show_legend=False,
    )
    f.add_charts([
        f"{n}: 100*(predict_{n} - {m}_{n})"
        for n in gperr_names
    ])

    f = ch.add_figure(
        "{country}: " + f"Information-adjusted {n} prediction error",
        show_legend=False,
        chart_type="histogram",
        vline=0,
    )
    f.add_charts([
        f"{n}: 100*(predict_{n} - {m}_{n})"
        for n in gperr_names
    ])

chartpack_generalized_perrs = ch
chartpack_iape = ch


#%% One-sided vs two-sided trend estimates

trend_names = [
    "log_gdp",
    "log_cpr_to_gdp",
    "log_cgg_to_gdp",
    "log_fcf_to_gdp",
    "log_xgs_to_gdp",
    "log_mgs_to_gdp",
    "log_roc_cpi",
    "i",
    "log_tot",
]


ch = dp.Chartpack(
    tiles=(4, 4),
    round_to=8,
)

f = ch.add_figure(
    "{country}: One-sided vs two-sided trend estimates",
    show_legend=True,
    legend=("Trend (update)", "Trend (smooth)", "Data", ),
)
f.add_charts([
    f"{n}: 100*(update_{n}_tnd | smooth_{n}_tnd | smooth_{n})"
    for n in trend_names
])

f = ch.add_figure(
    "{country}: One-sided vs two-sided trend estimates",
    show_legend=False,
)
f.add_charts([
    f"{n}: 100*(update_{n}_tnd - smooth_{n}_tnd)"
    for n in trend_names
])

f = ch.add_figure(
    "{country}: One-sided vs two-sided trend estimates",
    show_legend=False,
    chart_type="histogram",
    vline=0,
)
f.add_charts([
    f"{n}: 100*(update_{n}_tnd - smooth_{n}_tnd)"
    for n in trend_names
])

chartpack_trend_estimates = ch


