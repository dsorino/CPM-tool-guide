
#[

# Standard library imports
import os

# Third-party imports
import irispie as ir

#]


__all__ = (
    "chartpack_filter",
    "chartpack_external_filter",
)


chartpack_external_filter = ir.Chartpack(
    span=None,
    highlight=None,
    tiles=(3, 3, ),
)

f = chartpack_external_filter.add_figure("Filter report for {external_country}: Supporting variables", )
f.add_charts([
    "External GDP: gdpw | gdpw_tnd",
    "External GDP, Q/Q PA: 100*(roc_gdpw**4 - 1) | 100*(roc_gdpw_tnd**4 - 1)",
    "External GDP gap: 100*(gdpw_gap - 1)",
    "External CPI, Q/Q PA | Y/Y: 100*(roc_cpiw**4 - 1) | 100*(roc_cpiw_tnd**4 - 1)",
    "External nominal interest rate: 100*iw | 100*iw_tnd", 
    "External real interest rate: 100*riw | 100*riw_tnd", 
])


chartpack_filter = ir.Chartpack(
    span=None,
    highlight=None,
    tiles=(3, 3, ),
)

f = chartpack_filter.add_figure("Filter report for {country}: GDP components and trends", )
f.add_charts([
    "GDP: gdp | gdp_tnd",
    "Private consumption: cpr | cpr_tnd",
    "Government consumption: cgg | cgg_tnd",
    "Fixed capital formation: fcf | fcf_tnd",
    "Exports of goods and services: xgs | xgs_tnd",
    "Imports of goods and services: mgs | mgs_tnd",
    "Change in business inventories to GDP: cbi_to_gdp | cbi_to_gdp_tnd",
    "Statistical discrepancies to GDP: sdx_to_gdp"
])

f = chartpack_filter.add_figure("Filter report for {country}: GDP components and gaps", )
f.add_charts([
    "GDP: 100*(gdp_gap-1)",
    "Private consumption: 100*(cpr_gap-1)",
    "Government consumption: 100*(cgg_gap-1)",
    "Fixed capital formation: 100*(fcf_gap-1)",
    "Exports of goods and services: 100*(xgs_gap-1)",
    "Imports of goods and services: 100*(mgs_gap-1)",
    "Change in business inventories to GDP: cbi_to_gdp",
    "Statistical discrepancies to GDP: sdx_to_gdp"
])

f = chartpack_filter.add_figure("Filter report for {country}: GDP ratios and trends", )
f.add_charts([
    "Private consumption: cpr_to_gdp | cpr_to_gdp_tnd",
    "Government consumption: cgg_to_gdp | cgg_to_gdp_tnd",
    "Fixed capital formation: fcf_to_gdp | fcf_to_gdp_tnd",
    "Exports of goods and services: xgs_to_gdp | xgs_to_gdp_tnd",
    "Imports of goods and services: mgs_to_gdp | mgs_to_gdp_tnd",
    "Change in business inventories to GDP: cbi_to_gdp",
    "Statistical discrepancies to GDP: sdx_to_gdp"
])

f = chartpack_filter.add_figure("Filter report for {country}: Rates of change, Q/Q PA", )
f.add_charts([
    "Private consumption: 400*(cpr/cpr[-1]-1)",
    "Government consumption: 400*(cgg/cgg[-1]-1)",
    "Fixed capital formation: 400*(fcf/fcf[-1]-1)",
    "Exports of goods and services: 400*(xgs/xgs[-1]-1)",
    "Imports of goods and services: 400*(mgs/mgs[-1]-1)",
])

f = chartpack_filter.add_figure("Filter report for {country}: Supporting variables", )
f.add_charts([
    "Terms of trade: tot | tot_tnd",
    "CPI Q/Q PA: 400*(roc_cpi-1) | 400*(roc_cpi_tnd-1)",
    "Nominal interest rate: 100*i | 100*i_tnd",
    "Real interest rate: 100*ri | 100*ri_tnd",
    "Nominal exchange rate: e",
    "Real exchange rate: re | re_tnd",
    "UIP disparity: 100*disp | 100*disp_tnd",
])

chart_input_strings = chartpack_external_filter.figures[-1].get_chart_input_strings()
f = chartpack_filter.add_figure("Filter report for {external_country}: Supporting variables", )
f.add_charts(chart_input_strings, )

