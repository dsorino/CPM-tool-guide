#%% Create chartpacks (annual) to report steady-state calibration


#[

# Standard library imports
import functools as ft

# Third-party imports
import datapie as dp

#]


__all__ = (
    "chartpack_steady_calibration",
    "chartpack_external_steady_calibration",
    "prepare_steady_calibration_data",
    "prepare_external_steady_calibration_data",
)


#%% Create steady-state calibration chartpack


ch = dp.Chartpack(
    tiles=(3, 3, ),
    legend=("Data", "Weighted average", "Steady state", ),
    round_to=8,
    context={"filter": ft.partial(dp.decay_avg, decay=0.9, ), }
)

f = ch.add_figure("{country}: Steady-state GDP ratios", )
for n in ("cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx", ):
    f.add_chart(f"{n.upper()} to GDP, pct: 100*(yy_{n}_to_gdp | filter(yy_{n}_to_gdp) | ss_{n}_to_gdp)", )

f = ch.add_figure("{country}: Steady-state rates", )
f.add_charts((
    "GDP, pct rate of change: pct_yy_gdp | filter(pct_yy_gdp) | ss_pct_yy_gdp",
    "CPI, pct rate of change: pct_yy_cpi | filter(pct_yy_cpi) | ss_pct_yy_cpi",
    "Nominal USD exchange rate, pct rate of change: pct_yy_e | filter(pct_yy_e) | ss_pct_yy_e",
    "Real USD exchange rate, pct rate of change: pct_yy_re | filter(pct_yy_re) | ss_pct_yy_re",
    "Nominal interest rate, pct: 100*(yy_i | filter(yy_i) | ss_i)",
    "Real interest rate, pct: 100*(yy_ri_ex | filter(yy_ri_ex) | ss_ri)",
))

chartpack_steady_calibration = ch


#%% Create external steady-state calibration chartpack


ch = dp.Chartpack(
    tiles=(3, 3, ),
    legend=("Data", "Weighted average", "Steady state", ),
    round_to=8,
    context={"filter": ft.partial(dp.decay_avg, decay=0.9, ), }
)

f = ch.add_figure("{country}: Steady-state rates", )
f.add_charts((
    "GDP, pct rate of change: pct_yy_gdpw | filter(pct_yy_gdpw) | ss_pct_yy_gdpw",
    "CPI, pct rate of change: pct_yy_cpiw | filter(pct_yy_cpiw) | ss_pct_yy_cpiw",
    "Nominal USD exchange rate, pct rate of change: pct_yy_ew | filter(pct_yy_ew) | ss_pct_yy_ew",
    # "Real USD exchange rate, pct rate of change: pct_yy_re | filter(pct_yy_re) | ss_pct_yy_re",
    "Nominal interest rate, pct: 100*(yy_iw | filter(yy_iw) | ss_iw)",
    "Real interest rate, pct: 100*(yy_riw | filter(yy_riw) | ss_riw)",
))

chartpack_external_steady_calibration = ch


#%% Function to prepare data for steady-state calibration chartpack


def prepare_steady_calibration_data(db, model, ):
    #
    model.check_steady()
    ss = model.get_steady_levels()
    #
    for n in ("cpr", "cgg", "fcf", "xgs", "mgs", "cbi", "sdx", ):
        db[f"yy_{n}_to_gdp"] = db[f"yy_{n}"] / db["yy_gdp"]
        db[f"ss_{n}_to_gdp"] = ss[f"{n}_to_gdp"]
    #
    for n in ("gdp", "cpi", "e", "re", ):
        db[f"pct_yy_{n}"] = dp.pct(db[f"yy_{n}"])
        db[f"ss_pct_yy_{n}"] = 100 * (ss[f"roc_{n}"]**4 - 1)
    #
    for n in ("i", "ri", ):
        db[f"ss_{n}"] = ss[n]


def prepare_external_steady_calibration_data(db, model, ):
    #
    model.check_steady()
    ss = model.get_steady_levels()
    #
    for n in (
        "gdpw",
    ):
        if (n not in db) or (f"yy_{n}" in db):
            continue
        db[f"yy_{n}"] = dp.aggregate(db[n], dp.YEARLY, "sum", )
    #
    for n in (
        "cpiw", "ew", "iw" , "riw",
    ):
        if (n not in db) or (f"yy_{n}" in db):
            continue
        db[f"yy_{n}"] = dp.aggregate(db[n], dp.YEARLY, "mean", )
    #
    for n in ("gdpw", "cpiw", "ew", ):
        db[f"pct_yy_{n}"] = dp.pct(db[f"yy_{n}"])
        db[f"ss_pct_yy_{n}"] = 100 * (ss[f"roc_{n}"]**4 - 1)
    #
    for n in ("iw", "riw", ):
        db[f"ss_{n}"] = ss[n]

