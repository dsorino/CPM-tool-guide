#%% Create chartpacks (quarterly and annual) to report projections


#[

# Third-party imports
import datapie as dp

#]


__all__ = (
    "chartpack_forecast",
    "chartpack_external_forecast",
    "yy_chartpack_forecast",
    "yy_chartpack_external_forecast",
)


#%% Create forecast chartpacks

chartpack_forecast = dp.Chartpack(
    tiles=(3, 3),
    show_legend=False,
)

f = chartpack_forecast.add_figure("{country}: Real GDP ratios", )
f.add_charts([
    "Private consumption to GDP: cpr_to_gdp",
    "Government consumption to GDP: cgg_to_gdp",
    "Fixed capital formation to GDP: fcf_to_gdp",
    "Exports of goods and services to GDP: xgs_to_gdp",
    "Imports of goods and services to GDP: mgs_to_gdp",
    "Change in business inventories to GDP: cbi_to_gdp",
    "Statistical discrepancies to GDP: sdx_to_gdp",
])

f = chartpack_forecast.add_figure("{country}: Gaps in real GDP components", )
f.add_charts([
    "GDP: 100*(gdp_gap-1)",
    "Private consumption: 100*(cpr_gap-1)",
    "Government consumption: 100*(cgg_gap-1)",
    "Fixed capital formation: 100*(fcf_gap-1)",
    "Exports of goods and services: 100*(xgs_gap-1)",
    "Imports of goods and services: 100*(mgs_gap-1)",
])


f = chartpack_forecast.add_figure("{country}: Real GDP components, Q/Q PA", )
f.add_charts([
    "GDP: apct_gdp",
    "Private consumption: apct_cpr",
    "Government consumption: apct_cgg",
    "Fixed capital formation: apct_fcf",
    "Exports of goods and services: apct_xgs",
    "Imports of goods and services: apct_mgs",
])

f = chartpack_forecast.add_figure("{country}: Real GDP components, Annual pct", )
f.add_charts([
    "GDP: 100*(ann_gdp/ann_gdp[-4] - 1)",
    "Private consumption: 100*(ann_cpr/ann_cpr[-4] - 1)",
    "Government consumption: 100*(ann_cgg/ann_cgg[-4] - 1)",
    "Fixed capital formation: 100*(ann_fcf/ann_fcf[-4] - 1)",
    "Exports of goods and services: 100*(ann_xgs/ann_xgs[-4] - 1)",
    "Imports of goods and services: 100*(ann_mgs/ann_mgs[-4] - 1)",
])

f = chartpack_forecast.add_figure("{country}: Supporting variables", )
f.add_charts([
    "CPI, Q/Q PA: apct_cpi",
    "Nominal interest rate: 100*i", 
    "Nominal exchange rate (USD): e", 
    "Real interest rate: 100*ri | 100*ri_tnd", 
    "Real exchange rate, Q/Q PA: re | re_tnd", 
    "Real exchange rate, Q/Q PA: apct_re", 
    "Terms of trade: tot",
])

f = chartpack_forecast.add_figure("External environment", )
f.add_charts([
    "Effective external GDP gap: 100*(gdpwx_gap - 1)",
    "Effective external real exchange rate gap: 100*(rewx_gap - 1)",
    "Real USD exchange rate gap: 100*(re_gap - 1)",
    "US nominal interest rate: 100*iw", 
    "US real interest rate: 100*riw", 
    "Nominal USD exchange rate: e",
    "Real USD exchange rate: re | re_tnd",
])


chartpack_external_forecast = dp.Chartpack(
    tiles=(3, 3),
    show_legend=False,
)

f = chartpack_external_forecast.add_figure("{external_country}: External economy", )
f.add_charts([
    "External GDP: gdpw | gdpw_tnd",
    "External GDP gap: 100*(gdpw_gap - 1)",
    "External GDP, Q/Q PA: apct_gdpw | apct_gdpw_tnd",
    "External CPI, Q/Q PA: apct_cpiw",
    "External nominal interest rate: 100*iw", 
    "External real interest rate: 100*riw", 
    "External nominal USD exchange rate: ew",
    "External real USD exchange rate: rew | rew_tnd",
])


#%% Create forecast chartpacks for annual frequency data

yy_chartpack_forecast = dp.Chartpack(
    tiles=(3, 3),
    show_legend=False,
)

f = yy_chartpack_forecast.add_figure("{country}: Real GDP components, Y/Y")
f.add_charts([
    "GDP: yy_pct_gdp",
    "Private consumption: yy_pct_cpr",
    "Government consumption: yy_pct_cgg",
    "Fixed capital formation: yy_pct_fcf",
    "Exports of goods and services: yy_pct_xgs",
    "Imports of goods and services: yy_pct_mgs",
])

f = yy_chartpack_forecast.add_figure("{country}: Gaps in real GDP components")
f.add_charts([
    "GDP: 100*(yy_gdp_gap-1)",
    "Private consumption: 100*(yy_cpr_gap-1)",
    "Government consumption: 100*(yy_cgg_gap-1)",
    "Fixed capital formation: 100*(yy_fcf_gap-1)",
    "Exports of goods and services: 100*(yy_xgs_gap-1)",
    "Imports of goods and services: 100*(yy_mgs_gap-1)",
])

f = yy_chartpack_forecast.add_figure("{country}: Real GDP ratios", )
f.add_charts([
    "Private consumption to GDP: yy_cpr_to_gdp",
    "Government consumption to GDP: yy_cgg_to_gdp",
    "Fixed capital formation to GDP: yy_fcf_to_gdp",
    "Exports of goods and services to GDP: yy_xgs_to_gdp",
    "Imports of goods and services to GDP: yy_mgs_to_gdp",
    "Change in business inventories to GDP: yy_cbi_to_gdp",
    "Statistical discrepancies to GDP: yy_sdx_to_gdp",
])

f = yy_chartpack_forecast.add_figure("{country}: Supporting variables", )
f.add_charts([
    "CPI, Q/Q PA: yy_pct_cpi",
    "Nominal interest rate: 100*yy_i", 
    "Nominal exchange rate (USD): yy_e", 
    "Real interest rate: 100*yy_ri | 100*yy_ri_tnd", 
    "Real exchange rate, Q/Q PA: yy_re | yy_re_tnd", 
    "Real exchange rate, Q/Q PA: yy_pct_re", 
    "Terms of trade: yy_tot",
])



yy_chartpack_external_forecast = dp.Chartpack(
    tiles=(3, 3),
    show_legend=False,
)

f = yy_chartpack_external_forecast.add_figure("{external_country}: External economy", )
f.add_charts([
    "External GDP: yy_gdpw | yy_gdpw_tnd",
    "External GDP gap: 100*(yy_gdpw_gap - 1)",
    "External GDP, Y/Y: yy_pct_gdpw | yy_pct_gdpw_tnd",
    "External CPI, Y/Y: yy_pct_cpiw",
    "External nominal interest rate: 100*yy_iw", 
    "External real interest rate: 100*yy_riw", 
    "External nominal USD exchange rate: yy_ew",
])

