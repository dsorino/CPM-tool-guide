

#[

# Third-party imports
import prettytable as pt
import irispie as ir

#]


__all__ = (
    "create_external_steady_table",
    "create_steady_table",
)


def create_external_steady_table(
    model: ir.Simultaneous,
    round_to: int | None = None,
    write_to_csv_file: str = "",
) -> pt.PrettyTable:

    sl = model.get_steady_levels()
    to_report = {
        "Pct change in external real GDP": 100*(sl["roc_gdpw"]**4-1),
        "Pct change in external CPI": 100*(sl["roc_cpiw"]**4-1),
        "External nominal short-term interest rate": 100*sl["iw"],
        "External real short-term interest rate": 100*sl["riw"],
    }

    return create_steady_table_from_dict(
        to_report,
        round_to=round_to,
        write_to_csv_file=write_to_csv_file,
    )


def create_steady_table(
    model: ir.Simultaneous,
    round_to: int | None = None,
    write_to_csv_file: str = "",
) -> pt.PrettyTable:

    sl = model.get_steady_levels()
    to_report = {
        "Pct change in real GDP": 100*(sl["roc_gdp"]**4-1),
        "Consumption to GDP": 100*sl["cpr_to_gdp"],
        "Government consumption to GDP": 100*sl["cgg_to_gdp"],
        "Fixed capital formation to GDP": 100*sl["fcf_to_gdp"],
        "Change in business inventories to GDP": 100*sl["cbi_to_gdp"],
        "Exports of goods and services to GDP": 100*sl["xgs_to_gdp"],
        "Imports of goods and services to GDP": 100*sl["mgs_to_gdp"],
        "Pct change in CPI": 100*(sl["roc_cpi"]**4-1),
        "Nominal short-term interest rate": 100*sl["i"],
        "Real short-term interest rate": 100*sl["ri"],
        "Pct change in nominal exchange rate (USD)": 100*(sl["roc_e"]**4-1),
        "Pct change in real exchange rate": 100*(sl["roc_re"]**4-1),
        "Pct change in external real GDP": 100*(sl["roc_gdpw"]**4-1),
        "Pct change in external CPI": 100*(sl["roc_cpiw"]**4-1),
        "External nominal short-term interest rate": 100*sl["iw"],
        "External real short-term interest rate": 100*sl["riw"],
    }

    return create_steady_table_from_dict(
        to_report,
        round_to=round_to,
        write_to_csv_file=write_to_csv_file,
    )


def create_steady_table_from_dict(
    to_report: dict[str, float],
    round_to: int | None = None,
    write_to_csv_file: str = "",
) -> pt.PrettyTable:

    if round_to is not None:
        to_report = {k: round(v, round_to) for k, v in to_report.items()}

    table = pt.PrettyTable()
    table.field_names = ("Variable", "Steady state value", )
    table.align["Variable"] = "l"
    table.align["Steady state value"] = "r"
    table.title = "Steady state of the model"

    for var, val in to_report.items():
        table.add_row((var, val, ))

    if write_to_csv_file:
        _write_table_to_csv_file(table, write_to_csv_file, )

    return table


def _write_table_to_csv_file(
    table: pt.PrettyTable,
    file_name: str,
) -> None:
    r"""
    """
    with open(file_name, "w", encoding="utf-8", ) as f:
        f.write(table.get_csv_string())

