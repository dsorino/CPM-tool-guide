
import os
import irispie as ir


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILES_DIR = os.path.join(THIS_DIR, "data_files")
PREPROCESSED_DATA_FILE = os.path.join(DATA_FILES_DIR, "preprocessed_data.csv")


db = ir.Databox.from_csv_file(PREPROCESSED_DATA_FILE, )

ch = ir.Chartpack(
    span=ir.qq(2015,1) >> ir.qq(2025,4),
    tiles=(3, 3, ),
    show_legend=False,
)

f = ch.add_figure("External: United States", )
f.add_charts([
    "GDP, Q/Q PA | Y/Y: apct_gdpw | pct4_gdpw",
    "CPI, Q/Q PA | Y/Y: apct_cpiw | pct4_cpiw",
    "Nominal interest rate: 400*iw", 
    "Ex-post real interest rate: 400*riw_ex", 
])

ch.plot(db, )

