r"""
Retrieve historical data for the Philippines model
"""


#[

# Application imports
import datastore_api as api
import model_infrastructure as mi
from reporting_infrastructure import logger

# Local imports
from . import file_structure as fs

#]


#%% Defining attributes
logger.info("Defining attributes")

attributes = mi.read_attributes_from_json_file(fs.ATTRIBUTES_FILE, )


#%% Reading data in from datastore
logger.info("Reading data in from datastore")

input_mapping = api.read_mapping_from_csv_file(
    fs.INPUT_MAPPING_FILE,
    attributes=attributes,
)
db = api.request(input_mapping, )
db.to_csv_file(
    fs.REQUEST_DATA_FILE,
    description_row=True,
)


logger.info("Done reading in data")

