# China External Model

This repository contains the external environment model for China,
representing one of the key external economies in the forecasting system. It
provides projections for Chinese GDP, inflation, and interest rates that
influence the domestic economies being modeled.

